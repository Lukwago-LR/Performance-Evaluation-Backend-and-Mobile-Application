﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public interface IcommentsRepository
    {
        int comment(int C_ID, int ID, int Recipient, string Descrip, string comment_Type, int compReceiver);
        List<string> viewCommentAboutme(string id);
        List<string> viewComment_I_Made(string id);
        List<string> viewCommentaboutAdministrator(int id);
        List<string> getFeedback(string id);
        int getcommentNo(string id);
        int getfeedbackNo(string id);
        List<string> getverifiedadminComments(string id);
    }
}
