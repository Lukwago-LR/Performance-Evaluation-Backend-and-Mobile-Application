﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public interface IevaluationsRepository
    {
        decimal gettotalperformanceGrade();
        List<decimal> getresearcherGrade(int id);
        decimal getadminGrade(int id);
        List<string> evaluation_totalperf_percent_updating_Grades();
    }
}
