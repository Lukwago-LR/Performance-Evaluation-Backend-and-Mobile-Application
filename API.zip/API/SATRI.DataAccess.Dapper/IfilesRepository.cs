﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public interface IfilesRepository
    {
        int removeFile(string fileID);//unforward the file
        List<string> viewFiles(string id);
        List<string> getForwardedFile(string receiver);
        int uploadFile(int id, string fType, string fileName, int RecipID);
        List<string> getallverifiedFiles();
    }
}
