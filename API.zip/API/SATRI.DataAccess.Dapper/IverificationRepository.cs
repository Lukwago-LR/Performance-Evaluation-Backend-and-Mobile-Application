﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public interface IverificationRepository
    {
        int UpdateVerifiedAccount(int id, int veriferID);
        int UpdateFiles(string fileid, int senderid, string receiverId, string Filestatus);
        int UpdateVerifiedComments(int C_ID, string adminId, string receiverId);
    }
}

