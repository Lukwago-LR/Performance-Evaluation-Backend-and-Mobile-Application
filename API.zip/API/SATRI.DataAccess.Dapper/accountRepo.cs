﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public class accountRepo : accountRepository
    {
        protected readonly IConfiguration _config;
        protected readonly IcommentsRepository _Icom;
        protected readonly employeeRepository _Iemp;

        public accountRepo(IConfiguration config, IcommentsRepository Icom, employeeRepository Iemp)
        {
            _config = config;
            _Icom = Icom;
            _Iemp = Iemp;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("SATRI_db_Connection"));
            }
        }


        public List<string> getEmpDetailsAsync(string email, string password)
        {
            List<string> list = new List<string>();
            try
            {
                using (IDbConnection conn = Connection)
                {

                    SqlCommand cmd = new SqlCommand("spEmployeebyEmail_Password", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter e = new SqlParameter();
                    e.ParameterName = "@email";
                    e.SqlDbType = SqlDbType.VarChar;
                    e.Value = email;

                    SqlParameter p = new SqlParameter();
                    p.ParameterName = "@password";
                    p.SqlDbType = SqlDbType.VarChar;
                    p.Value = Mtdpassword(password);

                    cmd.Parameters.Add(e);
                    cmd.Parameters.Add(p);

                    
                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());
                    string str=null;
                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                             str = Convert.ToString(r.GetInt32(0)) + ":" + r.GetString(2) + ":" + r.GetString(3) + ":" + r.GetString(4) + ":" +
                                   r.GetString(5) + ":" + r.GetString(6) + ":" + r.GetString(7) + ":" + r.GetString(8);
                           
                        }                       

                    }

                    if (str != null)
                    {
                        list.Add(str);
                        conn.Close();
                        return list;
                    }
                    else
                    {
                        conn.Close();
                        return null;
                    }
                   
                }

            }
            catch (Exception e)
            {

                throw e;
            }

        }

        public List<string> getaccountbyUserType(string userT)
        {
            List<string> list = new List<string>();
            try
            {
                using (IDbConnection conn = Connection)
                {

                    SqlCommand cmd = new SqlCommand("spAccountForUpdateByUserType", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter e = new SqlParameter();
                    e.ParameterName = "@userType";
                    e.SqlDbType = SqlDbType.VarChar;
                    e.Value = userT;

                    cmd.Parameters.Add(e);
                   
                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());
                    string str = null;
                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            str = r.GetString(0) + ":" + r.GetString(1) + ":" + r.GetString(2) + ":" + Convert.ToString(r.GetInt32(3));
                            list.Add(str);
                        }

                    }

                    if (list.Count != 0)
                    {
                        conn.Close();
                        return list;
                    }
                    else
                    {
                        conn.Close();
                        return null;
                    }

                }

            }
            catch (Exception e)
            {

                throw e;
            }

        }

        public string[] Login(string email, string password)
        {
            string[] str = new string[3];
            try
            {
                using (IDbConnection conn = Connection)
                {

                    SqlCommand cmd = new SqlCommand("spEmployeebyEmail_Password", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    SqlParameter e = new SqlParameter();
                    e.ParameterName = "@email";
                    e.SqlDbType = SqlDbType.VarChar;
                    e.Value = email;

                    SqlParameter p = new SqlParameter();
                    p.ParameterName = "@password";
                    p.SqlDbType = SqlDbType.VarChar;
                    p.Value = Mtdpassword(password);

                    cmd.Parameters.Add(e);
                    cmd.Parameters.Add(p);               

                   

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());

                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            str[0] = Convert.ToString(r.GetInt32(0));
                           
                            str[1] = r.GetString(5);
                           
                            str[2] = r.GetString(7);

                        }

                    }

                    if (str[0] != null)
                    {
                        conn.Close();
                        return str;
                    }
                    else
                    {
                        conn.Close();
                        return null;
                    }
                }

            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public int RegisterAsync(string title, string firstname, string surname, string userType, string contact, string email, string password)
        {
            var emp = getEmpDetailsAsync(email, password);
            
            if (emp == null)
            {
                int sum;
                int es = email.GetHashCode();
                int ps = password.GetHashCode();
                sum = es + ps;
                if (sum < 0)
                {
                    sum = -1 * sum;
                } 

                try
                {
                    using (IDbConnection conn = Connection)
                    {

                        SqlCommand cmdq = new SqlCommand("spRegister", (SqlConnection)conn);
                        cmdq.CommandType = CommandType.StoredProcedure;
                        conn.Open();


                        SqlParameter i = new SqlParameter();
                        i.ParameterName = "@id";
                        i.SqlDbType = SqlDbType.Int;
                        i.Value = sum;

                        SqlParameter q = new SqlParameter();
                        q.ParameterName = "@title";
                        q.SqlDbType = SqlDbType.VarChar;
                        q.Value = title;

                        SqlParameter fn = new SqlParameter();
                        fn.ParameterName = "@firstName";
                        fn.SqlDbType = SqlDbType.VarChar;
                        fn.Value = firstname;

                        SqlParameter sn = new SqlParameter();
                        sn.ParameterName = "@surname";
                        sn.SqlDbType = SqlDbType.VarChar;
                        sn.Value = surname;

                        SqlParameter c = new SqlParameter();
                        c.ParameterName = "@contact";
                        c.SqlDbType = SqlDbType.VarChar;
                        c.Value = contact;

                        SqlParameter us = new SqlParameter();
                        us.ParameterName = "@userType";
                        us.SqlDbType = SqlDbType.VarChar;
                        us.Value = userType;


                        SqlParameter e = new SqlParameter();
                        e.ParameterName = "@email";
                        e.SqlDbType = SqlDbType.VarChar;
                        e.Value = email;

                        SqlParameter st = new SqlParameter();
                        st.ParameterName = "@st";
                        st.SqlDbType = SqlDbType.VarChar;
                        st.Value = "UNVERIFIED";

                        SqlParameter p = new SqlParameter();
                        p.ParameterName = "@password";
                        p.SqlDbType = SqlDbType.VarChar;
                        p.Value = Mtdpassword(password);

                        cmdq.Parameters.Add(i);
                        cmdq.Parameters.Add(q);
                        cmdq.Parameters.Add(fn);
                        cmdq.Parameters.Add(sn);
                        cmdq.Parameters.Add(c);
                        cmdq.Parameters.Add(us);
                        cmdq.Parameters.Add(e);
                        cmdq.Parameters.Add(st);
                        cmdq.Parameters.Add(p);

                        cmdq.ExecuteNonQuery();

                        conn.Close();

                        if (userType.Equals("ADMINISTRATOR"))
                        {
                          
                            List<string> strL = _Iemp.getEmployeeByUserType("EXECUTIVE_DIRECTOR");
                            if (strL != null)
                            {
                                string[] scon = strL[0].Split(':');
                                int num = _Icom.comment(sum, sum, Convert.ToInt32(scon[0]), "Request to verify account", "FEEDBACK", 0);
                            }                                

                        }
                        else if (userType.Equals("RESEARCHER") || userType.Equals("SENIOR_RESEARCHER"))
                        {
                            
                            if (userType.Equals("RESEARCHER"))
                            {
                                List<string> strL = _Iemp.getEmployeeByUserType("SENIOR_RESEARCHER");

                                if (strL.Count > 0)
                                {
                                    int number = new Random().Next(2);

                                    if (strL.Count > 1 && number == 1)
                                    {
                                        string[] dim = new string[4];
                                        foreach (string si in strL)
                                        {
                                            dim = si.Split(':');
                                            
                                        }
                                        int num = _Icom.comment(sum, sum, Convert.ToInt32(dim[0]), "Request to verify account", "FEEDBACK", 0);

                                    }
                                    else
                                    {
                                        string[] scon = new string[4];
                                        foreach (string si in strL)
                                        {
                                            scon = si.Split(':');                                           

                                        }
                                        int num = _Icom.comment(sum, sum, Convert.ToInt32(scon[0]), "Request to verify account", "FEEDBACK", 0);

                                    }

                                }

                            }

                           
                           

                        }
                        return 1;

                    }
                  

                }
                catch (Exception e)
                {
                    e.GetBaseException();
                    return -1;                
                 
                }

            }
            else
            {
                return 0;
            }            
        }

       

        private string Mtdpassword(string password)
        {
            SHA1 algorithmn = System.Security.Cryptography.SHA1.Create();
            byte[] array = algorithmn.ComputeHash(Encoding.Default.GetBytes(password));
            string hashedPassword = "";
            for (int i = 0; i < array.Length - 1; i++)
            {
                hashedPassword += array[i].ToString("x2");
            }

            return hashedPassword;
        }


        private int upContact(List<string> employ,string cont, int id)
        {
            if (employ != null)
            {
                try
                {
                    using (IDbConnection conn = Connection)
                    {

                        SqlCommand cmd = new SqlCommand("spupdateContact", (SqlConnection)conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        conn.Open();


                        SqlParameter c = new SqlParameter();
                        c.ParameterName = "@contact";
                        c.SqlDbType = SqlDbType.VarChar;
                        c.Value = cont;                    

                        SqlParameter i = new SqlParameter();
                        i.ParameterName = "@id";
                        i.SqlDbType = SqlDbType.Int;
                        i.Value = id;

                        cmd.Parameters.Add(c);                       
                        cmd.Parameters.Add(i);

                        cmd.ExecuteNonQuery();
                        conn.Close();
                        return 1;
                    }


                }
                catch (Exception e)
                {
                    e.GetBaseException();
                    return -1;

                }

            }
            else
            {
                return -1;//employee does not exist
            }

        }

        private int upEmail(List<string> employ, string eM, int id)
        {
            if (employ != null)
            {
                try
                {
                    using (IDbConnection conn = Connection)
                    {

                        SqlCommand cmd = new SqlCommand("spupdateEmail", (SqlConnection)conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        conn.Open();

                        SqlParameter e = new SqlParameter();
                        e.ParameterName = "@email";
                        e.SqlDbType = SqlDbType.VarChar;
                        e.Value = eM;

                        SqlParameter i = new SqlParameter();
                        i.ParameterName = "@id";
                        i.SqlDbType = SqlDbType.Int;
                        i.Value = id;

                        cmd.Parameters.Add(e);
                        cmd.Parameters.Add(i);

                        cmd.ExecuteNonQuery();
                        conn.Close();
                        return 1;
                    }


                }
                catch (Exception e)
                {
                    e.GetBaseException();
                    return -1;
                }

            }
            else
            {
                return -1;//employee does not exist
            }

        }

        private int upPassword(List<string> employ, string pass, int id)
        {
            if (employ != null)
            {
                try
                {
                    using (IDbConnection conn = Connection)
                    {

                        SqlCommand cmd = new SqlCommand("spupdateProfile", (SqlConnection)conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        conn.Open();

                        SqlParameter p = new SqlParameter();
                        p.ParameterName = "@password";
                        p.SqlDbType = SqlDbType.VarChar;
                        p.Value = Mtdpassword(pass);

                        SqlParameter i = new SqlParameter();
                        i.ParameterName = "@id";
                        i.SqlDbType = SqlDbType.Int;
                        i.Value = id;

                        cmd.Parameters.Add(p);
                        cmd.Parameters.Add(i);

                        cmd.ExecuteNonQuery();
                        conn.Close();
                        return 1;
                    }


                }
                catch (Exception e)
                {
                    e.GetBaseException();
                    return -1;

                }

            }
            else
            {
                return -1;//employee does not exist
            }

        }


        public int updateProfile(string contact, string email, string password, int ID)
        {
           var emp = getEmpDetailsAsync(email, password);
           int n1 = upContact(emp, contact, ID);
           int n2 = upEmail(emp, email, ID);
           int n3 =  upPassword(emp, password, ID);

            return n1* n2* n3;
        }
    }
}
