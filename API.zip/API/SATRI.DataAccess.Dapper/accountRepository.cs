﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public interface accountRepository
    {
        int RegisterAsync(string title, string firstname, string surname, string userType, string contact, string email, string password);
        List<string> getEmpDetailsAsync(string email, string password);
        string[] Login(string email, string password);
        int updateProfile(string contact, string email, string password, int ID);
        List<string> getaccountbyUserType(string userT);

    }
}
