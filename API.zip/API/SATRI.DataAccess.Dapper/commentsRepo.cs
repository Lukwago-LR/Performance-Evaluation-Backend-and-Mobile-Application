﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public class commentsRepo : IcommentsRepository
    {

        protected readonly IConfiguration _config;
        protected readonly employeeRepository _Iemp;
      
        public commentsRepo(IConfiguration config, employeeRepository Iemp)
        {
            _config = config;
            _Iemp = Iemp;
           
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("SATRI_db_Connection"));
            }
        }

        public int inserFeedback(int id)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd1 = new SqlCommand("spfeebackComment", (SqlConnection)conn);
                    cmd1.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter c = new SqlParameter();
                    c.ParameterName = "@CID";
                    c.SqlDbType = SqlDbType.VarChar;
                    c.Value = Convert.ToString(id);

                    cmd1.Parameters.Add(c);
                    cmd1.ExecuteNonQuery();
                    conn.Close();
                    return 1;
                }

            }
            catch (Exception e)
            {
                e.GetBaseException();
                return -1;
            }
        }

        public int inserFComplement(int id, int compReceiver)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd2 = new SqlCommand("spcomplementComment", (SqlConnection)conn);
                    cmd2.CommandType = CommandType.StoredProcedure;

                    conn.Open();

                    SqlParameter c = new SqlParameter();
                    c.ParameterName = "@CID";
                    c.SqlDbType = SqlDbType.VarChar;
                    c.Value = Convert.ToString(id);


                    SqlParameter c2 = new SqlParameter();
                    c2.ParameterName = "@complement_To";
                    c2.SqlDbType = SqlDbType.VarChar;
                    c2.Value = Convert.ToString(compReceiver);

                    cmd2.Parameters.Add(c);
                    cmd2.Parameters.Add(c2);

                    cmd2.ExecuteNonQuery();
                    return 1;
                }

            }
            catch (Exception e)
            {
                e.GetBaseException();
                return -1;
            }
        }

        public int inserFComplaint(int id, int compReceiver)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd2 = new SqlCommand("spcomplaintComment", (SqlConnection)conn);
                    cmd2.CommandType = CommandType.StoredProcedure;

                    conn.Open();

                    SqlParameter c = new SqlParameter();
                    c.ParameterName = "@CID";
                    c.SqlDbType = SqlDbType.VarChar;
                    c.Value = Convert.ToString(id);


                    SqlParameter c2 = new SqlParameter();
                    c2.ParameterName = "@complaintAbout";
                    c2.SqlDbType = SqlDbType.VarChar;
                    c2.Value = Convert.ToString(compReceiver);

                    cmd2.Parameters.Add(c);
                    cmd2.Parameters.Add(c2);

                    cmd2.ExecuteNonQuery();
                    return 1;
                }

            }
            catch (Exception e)
            {
                e.GetBaseException();
                return -1;
            }
        }


        public int comment(int C_ID, int ID, int Recipient, string Descrip, string comment_Type, int compReceiver)
        {


            int IDET = random() + C_ID;
            try
            {
                using (IDbConnection conn = Connection)
                {

                    SqlCommand cmd = new SqlCommand("spComment", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();


                    SqlParameter c = new SqlParameter();
                    c.ParameterName = "@CID";
                    c.SqlDbType = SqlDbType.VarChar;
                    c.Value = Convert.ToString(IDET);

                    SqlParameter s = new SqlParameter();
                    s.ParameterName = "@senderId";
                    s.SqlDbType = SqlDbType.Int;
                    s.Value = ID;

                    SqlParameter r = new SqlParameter();
                    r.ParameterName = "@receipientId";
                    r.SqlDbType = SqlDbType.VarChar;
                    r.Value = Convert.ToString(Recipient);

                    SqlParameter d = new SqlParameter();
                    d.ParameterName = "@cDate";
                    d.SqlDbType = SqlDbType.Date;
                    d.Value = DateTime.Today;

                    SqlParameter e = new SqlParameter();

                    if (comment_Type.Equals("FEEDBACK"))
                    {
                        e.ParameterName = "@descrip";
                        e.SqlDbType = SqlDbType.VarChar;
                        e.Value = Descrip + "&FEEDBACK";

                    }
                    else if (comment_Type.Equals("COMPLEMENT"))
                    {                       
                        e.ParameterName = "@descrip";
                        e.SqlDbType = SqlDbType.VarChar;
                        e.Value = Descrip + "&COMPLEMENT";

                    }
                    else
                    {                        
                        e.ParameterName = "@descrip";
                        e.SqlDbType = SqlDbType.VarChar;
                        e.Value = Descrip + "&COMPLAINT";
                    }

                   

                    cmd.Parameters.Add(c);
                    cmd.Parameters.Add(s);
                    cmd.Parameters.Add(r);
                    cmd.Parameters.Add(d);
                    cmd.Parameters.Add(e);

                    cmd.ExecuteNonQuery();



                    if (comment_Type.Equals("FEEDBACK"))
                    {
                        int num = inserFeedback(IDET);

                    }
                    else if (comment_Type.Equals("COMPLEMENT"))
                    {

                        int num = inserFComplement(IDET, compReceiver);
                    }
                    else
                    {
                        int num = inserFComplaint(IDET, compReceiver);

                    }
                  
                    conn.Close();
                    return 1;

                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
                return -1;
            }
        }

        public int getcommentNo(string id)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spgetcommentNo", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();

                    SqlParameter c = new SqlParameter();
                    c.ParameterName = "@id";
                    c.SqlDbType = SqlDbType.VarChar;
                    c.Value = id;

                    cmd.Parameters.Add(c);

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());
                    int num = 0;
                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            num = r.GetInt32(0); 
                        }

                    }

                    return num;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public List<string> getFeedback(string id)
        {
            List<string> list = new List<string>(); 

            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spreceivedFeedback", (SqlConnection)conn);                  

                    cmd.CommandType = CommandType.StoredProcedure;
                   
                    conn.Open();

                    SqlParameter c = new SqlParameter();
                    c.ParameterName = "@id";
                    c.SqlDbType = SqlDbType.Int;
                    c.Value = id;

                    cmd.Parameters.Add(c);

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());

                    string str = "";
                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            updatecommentStatus(r.GetString(0));

                            List<string> s = _Iemp.getEmployeebyIdAsync(r.GetInt32(1));
                            string[] dep = r.GetString(2).Split('&');

                            str = s[1] + " " + s[2] + ":" + dep[0] + ":" + dep[1] + ":" + r.GetDateTime(3);
                            list.Add(str);
                        }

                    }

                    if (str != null)
                    { 
                        conn.Close();
                        return list;
                    }
                    else
                    {
                        conn.Close();
                        return null;
                    }

                }

            }catch(Exception e)
            {
                throw e;
            }
        }

        public int getfeedbackNo(string id)
        {

            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spfeedbackNo", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();

                    SqlParameter c = new SqlParameter();
                    c.ParameterName = "@id";
                    c.SqlDbType = SqlDbType.VarChar;
                    c.Value = id;

                    cmd.Parameters.Add(c);

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());
                    int num = 0;
                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            num = r.GetInt32(0);
                        }

                    }

                    return num;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private void updatecommentStatus(string C_ID)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd3 = new SqlCommand("spupdatecommentStatus", (SqlConnection)conn);
                    cmd3.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter c3 = new SqlParameter();
                    c3.ParameterName = "@CID";
                    c3.SqlDbType = SqlDbType.VarChar;
                    c3.Value = C_ID;

                    cmd3.Parameters.Add(c3);

                    cmd3.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        private void updateverifiedComment(string C_ID)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd3 = new SqlCommand("spupdateverifedStatus", (SqlConnection)conn);
                    cmd3.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter c3 = new SqlParameter();
                    c3.ParameterName = "@CID";
                    c3.SqlDbType = SqlDbType.VarChar;
                    c3.Value = C_ID;

                    cmd3.Parameters.Add(c3);

                    cmd3.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public List<string> viewCommentaboutAdministrator(int id)
        {
            List<string> L = _Iemp.getEmployeeByUserType("ADMINISTRATOR");
            List<string> Lis = new List<string>();

            if (L != null)
            {
                

                foreach (string s in L)
                {

                    string[] str = s.Split(':');

                    using (IDbConnection conn = Connection)
                    {
                        SqlCommand cmd1 = new SqlCommand("spgetadminComments", (SqlConnection)conn);
                        cmd1.CommandType = CommandType.StoredProcedure;

                        conn.Open();

                        SqlParameter c2 = new SqlParameter();
                        c2.ParameterName = "@id";
                        c2.SqlDbType = SqlDbType.VarChar;
                        c2.Value = str[0];

                        SqlParameter c = new SqlParameter();
                        c.ParameterName = "@rep";
                        c.SqlDbType = SqlDbType.VarChar;
                        c.Value = Convert.ToString(id);

                        cmd1.Parameters.Add(c);

                        cmd1.Parameters.Add(c2);

                        SqlDataReader r1 = cmd1.EndExecuteReader(cmd1.BeginExecuteReader());

                        while (r1.Read())
                        {
                            if (r1.HasRows)
                            {
                                updatecommentStatus(r1.GetString(0));

                                string[] a = r1.GetString(2).Split('&');

                                string str1 = str[1] + " " + str[2] + ":" + str[3] + ":" + a[0] + ":" + a[1] + ":" + r1.GetString(0) + ":" + str[0] + ":" + r1.GetInt32(3) + ":" + r1.GetDateTime(4);
                                if (str1 != null)
                                {
                                    Lis.Add(str1);
                                }

                            }

                        }
                        r1.Close();
                        conn.Close();
                    }
                    
                }
               
            }


            if (Lis.Count != 0)
            {
                return Lis;
            }
            else
            {
                return null;
            }          

        }

        public List<string> viewCommentAboutme(string id)
        {
            List<string> list = new List<string>();

            using (IDbConnection conn = Connection)
            {
                SqlCommand cmd1 = new SqlCommand("spcommentsaboutMe", (SqlConnection)conn);
                cmd1.CommandType = CommandType.StoredProcedure;

                conn.Open();

                SqlParameter c = new SqlParameter();
                c.ParameterName = "@id";
                c.SqlDbType = SqlDbType.VarChar;
                c.Value = id;
                cmd1.Parameters.Add(c);

                SqlDataReader r1 = cmd1.EndExecuteReader(cmd1.BeginExecuteReader());

                while (r1.Read())
                {
                    if (r1.HasRows)
                    {                     

                        List<string> str2;

                        string s1 = personComplemented(r1.GetString(0));
                        if (s1 != null)
                        {
                            str2 = _Iemp.getEmployeebyIdAsync(Convert.ToInt32(s1));                            
                        }
                        else
                        {
                            string s2 = personComplaintedAbout(r1.GetString(0));
                            str2 = _Iemp.getEmployeebyIdAsync(Convert.ToInt32(s2));
                        }

                        if (!(r1.GetString(2).Equals("EVALUATED")))
                        {
                            updatecommentStatus(r1.GetString(0));
                        }                        

                        List<string> str = _Iemp.getEmployeebyIdAsync(Convert.ToInt32(r1.GetString(1)));

                        string[] s = r1.GetString(3).Split('&');
                                               
                        
                         string str1 = str[1] + " " + str[2] + ":" + r1.GetString(2) + ":" + s[0] + ":" + s[1] + ":" + r1.GetDateTime(4) + ":"  + str2[1] + " " + str2[2];
                                                
                        if (str1 != null)
                        {
                            list.Add(str1);
                        }

                    }

                }
                r1.Close();
                conn.Close();
            }

            if (list.Count != 0)
            {
                return list;
            }
            else
            {
                return null;
            }

        }

        private string personComplemented(string cid)
        {
            string comId = null;
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd3 = new SqlCommand("spmyComplement", (SqlConnection)conn);
                    cmd3.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter c3 = new SqlParameter();
                    c3.ParameterName = "@cid";
                    c3.SqlDbType = SqlDbType.VarChar;
                    c3.Value = cid;

                    cmd3.Parameters.Add(c3);

                    SqlDataReader r1 = cmd3.EndExecuteReader(cmd3.BeginExecuteReader());

                    while (r1.Read())
                    {
                        if (r1.HasRows)
                        {
                            comId = r1.GetString(0);
                        }
                       
                    }
                    r1.Close();
                    conn.Close();

                    if (comId != null)
                    {
                        return comId;
                    }
                    return null;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private string personComplaintedAbout(string cid)
        {
            string comId = null;
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd3 = new SqlCommand("spmyComplts", (SqlConnection)conn);
                    cmd3.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter c3 = new SqlParameter();
                    c3.ParameterName = "@c";
                    c3.SqlDbType = SqlDbType.VarChar;
                    c3.Value = cid;

                    cmd3.Parameters.Add(c3);

                    SqlDataReader r1 = cmd3.EndExecuteReader(cmd3.BeginExecuteReader());

                    while (r1.Read())
                    {
                        if (r1.HasRows)
                        {
                            comId = r1.GetString(0);
                        }

                    }
                    r1.Close();
                    conn.Close();

                    if (comId != null)
                    {
                        return comId;
                    }
                    return null;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public List<string> viewComment_I_Made(string id)
        {
            List<string> list = new List<string>();
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd1 = new SqlCommand("spgetcomments_I_Made", (SqlConnection)conn);
                    cmd1.CommandType = CommandType.StoredProcedure;

                    conn.Open();

                    SqlParameter c = new SqlParameter();
                    c.ParameterName = "@id";
                    c.SqlDbType = SqlDbType.Int;
                    c.Value = Convert.ToInt32(id);
                    cmd1.Parameters.Add(c);

                    SqlDataReader r1 = cmd1.EndExecuteReader(cmd1.BeginExecuteReader());

                    while (r1.Read())
                    {
                        if (r1.HasRows)
                        {
                            List<string> str2;
                                                       
                            string s1 = personComplemented(r1.GetString(0));
                            if (s1 != null)
                            {
                                str2 = _Iemp.getEmployeebyIdAsync(Convert.ToInt32(s1));
                            }
                            else
                            {
                                string s2 = personComplaintedAbout(r1.GetString(0));
                                str2 = _Iemp.getEmployeebyIdAsync(Convert.ToInt32(s2));
                            }

                            string[] des = r1.GetString(3).Split('&');

                            List<string> str = _Iemp.getEmployeebyIdAsync(Convert.ToInt32(r1.GetString(1)));

                            string str1 = str[1] + " " + str[2] + ":" + str2[1] + " " + str2[2] + ":" + r1.GetString(2) + ":" + des[0] + ":" + des[1] + ":" + r1.GetDateTime(4);
                            if (str1 != null)
                            {
                                list.Add(str1);
                            }

                        }

                    }
                    r1.Close();
                    conn.Close();
                }

                if (list.Count != 0)
                {
                    return list;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception e)
            {
                  throw e;
            }

        }

        private int random()
        {
            Random num = new Random();
            return num.Next(2000000, 5000000);
        }

        public List<string> getverifiedadminComments(string id)
        {
            List<string> l = new List<string>();
            try
            {
                using (IDbConnection conn = Connection)
                {

                    SqlCommand cmd1 = new SqlCommand("spgetverifiedadminComments", (SqlConnection)conn);
                    cmd1.CommandType = CommandType.StoredProcedure;

                    conn.Open();

                    SqlParameter c = new SqlParameter();
                    c.ParameterName = "@id";
                    c.SqlDbType = SqlDbType.VarChar;
                    c.Value = id;

                    cmd1.Parameters.Add(c);

                    SqlDataReader r1 = cmd1.EndExecuteReader(cmd1.BeginExecuteReader());

                    while (r1.Read())
                    {
                        if (r1.HasRows)
                        {
                            updateverifiedComment(r1.GetString(0));
                            string[] s = r1.GetString(1).Split('&');
                            string s2 = r1.GetString(0) + ":" + s[1];
                            l.Add(s2);
                        }

                    }
                    conn.Close();
                    if (l.Count != 0)
                    {                       
                        return l;
                    }
                    else
                    {                        
                        return null;
                    }
                    
                }
            }catch(Exception e)
            {
                throw e;
            }
        }

    }
}
