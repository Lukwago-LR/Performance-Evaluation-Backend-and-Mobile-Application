﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public class employeeRepo : employeeRepository
    {
        protected readonly IConfiguration _config;

        public employeeRepo(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("SATRI_db_Connection"));
            }
        }

        public List<string> getallEmployeeAsync()
        {
            List<string> l = new List<string>();

            try
            {
                using (IDbConnection dbconn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spAllEmployees", (SqlConnection)dbconn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    dbconn.Open();
                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());
                    if (r.HasRows)
                    {
                        while (r.Read())
                        {
                            string str = r.GetString(5) + ":" + r.GetString(3) + ":" + r.GetString(2) + ":" + r.GetString(8) + ":" +
                                         r.GetString(4) + ":" + r.GetString(6) + ":" + Convert.ToString(r.GetInt32(0));

                            l.Add(str);
                        }

                        dbconn.Close();
                        return l;
                    }
                    else
                    {
                        
                        dbconn.Close();
                        return null;
                    }
                   
                                     
                }

            } catch (Exception e)
            {
                throw e;
               
            }
          
        }

        public List<string> getEmployeebyIdAsync(int id)
        {
            List<string> l = new List<string>();
            try
            {
                using (IDbConnection dbconn = Connection)
                {
                   
                    SqlCommand cmd = new SqlCommand("spEmployee_by_ID", (SqlConnection)dbconn);
                    cmd.CommandType = CommandType.StoredProcedure;


                    dbconn.Open();
                    SqlParameter pID = new SqlParameter();
                    pID.ParameterName = "@id";
                    pID.SqlDbType = SqlDbType.Int;
                    pID.Value = id;

                    cmd.Parameters.Add(pID);
                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());
                   
                    while (r.Read())
                    {
                        if (r.HasRows)
                        {

                            l.Add(r.GetString(4));
                            l.Add(r.GetString(2));
                            l.Add(r.GetString(1));
                            l.Add(r.GetString(7));
                            l.Add(r.GetString(3));
                            l.Add(r.GetString(5));
                            l.Add(Convert.ToString(r.GetInt32(0)));


                        }

                    }

                    if (l.Count!=0)
                    {
                        dbconn.Close();
                        return l;
                    }
                    else
                    {
                        return null;
                    }


                }

            }
            catch (Exception e)
            {
                throw e;
            }
   
        }

        public List<string> getEmployeeByUserType(string userT)
        {
            List<string> lis = new List<string>();
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spemployeeByUserType", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();

                    SqlParameter p = new SqlParameter();
                    p.ParameterName = "@userType";
                    p.SqlDbType = SqlDbType.VarChar;
                    p.Value = userT;

                    cmd.Parameters.Add(p);

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());

                    
                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            string str = Convert.ToString(r.GetInt32(0)) + ":" + r.GetString(1) + ":" + r.GetString(2) + ":" + r.GetString(3);
                            lis.Add(str);
                     
                        }
                    }
                    if (lis.Count != 0)
                    {
                        return lis;
                    }
                    else
                    {
                        return null;
                    }
                }
            }catch (Exception e)
            {
                throw e;                

            }
        }
    }
}
