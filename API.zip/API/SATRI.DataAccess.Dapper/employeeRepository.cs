﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public interface employeeRepository
    {
        List<string> getEmployeebyIdAsync(int id);
        List<string> getallEmployeeAsync();
        List<string> getEmployeeByUserType(string userT);
    }
}
