﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public class evaluationsRepo : IevaluationsRepository
    {
        protected readonly IConfiguration _config;
        protected readonly employeeRepository _Iemp;
        protected readonly IcommentsRepository _Icom;
        protected readonly IfilesRepository _If;

        public evaluationsRepo(IConfiguration config, employeeRepository Iemp, IcommentsRepository Icom, IfilesRepository If)
        {
            _config = config;
            _Iemp = Iemp;
            _Icom = Icom;
            _If = If;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("SATRI_db_Connection"));
            }
        }

        public decimal getadminGrade(int id)
        {

            decimal d = 0;
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("sptotaladministratorMark", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    SqlParameter I = new SqlParameter();
                    I.ParameterName = "@id";
                    I.SqlDbType = SqlDbType.Int;
                    I.Value = id;

                    cmd.Parameters.Add(I);

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());

                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            d = r.GetDecimal(0);                       
                           
                        }

                    }

                    return d;
                    
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public List<decimal> getresearcherGrade(int id)
        {
            decimal diss = 0;
            decimal pub = 0;
            decimal proj = 0;
            decimal tot = 0;

            List<decimal> l = new List<decimal>();
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("sptotalresearcherMark", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    SqlParameter I = new SqlParameter();
                    I.ParameterName = "@id";
                    I.SqlDbType = SqlDbType.Int;
                    I.Value = id;

                    cmd.Parameters.Add(I);

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());

                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            diss = r.GetDecimal(0);
                            pub = r.GetDecimal(1);
                            proj = r.GetDecimal(2);
                            tot = r.GetDecimal(3);
                        }

                    }

                    l.Add(diss);
                    l.Add(pub);
                    l.Add(proj);
                    l.Add(tot);

                    if(l != null)
                    {
                        return l;
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        private void updateadminComment(int id, decimal d)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spupdateadminCommentMark", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    SqlParameter a = new SqlParameter();
                    a.ParameterName = "@id";
                    a.SqlDbType = SqlDbType.Int;
                    a.Value = id;

                    SqlParameter I = new SqlParameter();
                    I.ParameterName = "@dec";
                    I.SqlDbType = SqlDbType.Decimal;
                    I.Value = Math.Round(d,3);

                    cmd.Parameters.Add(a);
                    cmd.Parameters.Add(I);

                    cmd.ExecuteNonQuery();

                    conn.Close();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private void updateresearcherMarks(int id, decimal diss, decimal pub, decimal proj)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {

                    SqlCommand cmd = new SqlCommand("spupdateresearcherMark", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    SqlParameter a = new SqlParameter();
                    a.ParameterName = "@id";
                    a.SqlDbType = SqlDbType.Int;
                    a.Value = id;

                    SqlParameter I = new SqlParameter();
                    I.ParameterName = "@diss";
                    I.SqlDbType = SqlDbType.Decimal;
                    I.Value = Math.Round(diss,3);

                    SqlParameter b = new SqlParameter();
                    b.ParameterName = "@pub";
                    b.SqlDbType = SqlDbType.Decimal;
                    b.Value = Math.Round(pub,3);

                    SqlParameter d = new SqlParameter();
                    d.ParameterName = "@proj";
                    d.SqlDbType = SqlDbType.Decimal;
                    d.Value = Math.Round(proj,3);

                    cmd.Parameters.Add(a);
                    cmd.Parameters.Add(I);
                    cmd.Parameters.Add(b);
                    cmd.Parameters.Add(d);

                    cmd.ExecuteNonQuery();

                    conn.Close();
                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public decimal gettotalperformanceGrade()
        {

            decimal total = 0;
            List<string> l = _Iemp.getEmployeeByUserType("RESEARCHER");
            List<string> l3 = _Iemp.getEmployeeByUserType("SENIOR_RESEARCHER");
            List<string> l2 = _Iemp.getEmployeeByUserType("ADMINISTRATOR");

            if (l != null)
            {
                foreach (string s1 in l)
                {
                    string[] str = s1.Split(':');
                    List<decimal> g = getresearcherGrade(Convert.ToInt32(str[0]));
                    total += g[3];
                }
            }

            if (l3 != null)
            {
                foreach (string s1 in l3)
                {
                    string[] str = s1.Split(':');
                    List<decimal> g = getresearcherGrade(Convert.ToInt32(str[0]));
                    total += g[3];
                }
            }

            if (l2 != null)
            {
                foreach (string s2 in l2)
                {
                    string[] str = s2.Split(':');
                    decimal d = getadminGrade(Convert.ToInt32(str[0]));
                    total += d;
                }

            }
           
            return total;
        }

        private List<string> autoevaluationCycle(int num)
        {
            //atleast every researcher must have 9 accomplishments at the end of the year
            //atleast each administrator must have 9 complemnts at the end of the year

            decimal Accomplishments = gettotalperformanceGrade();
            decimal dec = Math.Round((Accomplishments / (num * 9)) * 100, 3);
            List<string> l = new List<string>();
            

            if (DateTime.Now.Month  < 4)
            {  
                if(Accomplishments < (num * 3))
                {
                    string s = "Poor Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l; 
                }
                else if (Accomplishments == (num * 3))
                {
                    string s = "Average Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }
                else if(Accomplishments > (num*3) && (Accomplishments < 9 + (num * 3)))
                {                   
                    string s = "Good Performance" + ":" + Convert.ToString(dec)+ "%";
                    l.Add(s);
                    return l;
                }
                else
                {
                    string s = "Excellent Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }
                           

            }
            else if(DateTime.Now.Month > 3 && DateTime.Now.Month < 8)
            {

                if (Accomplishments < (num * 6))
                {
                    string s = "Poor Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }
                else if (Accomplishments == (num * 6))
                {
                    string s = "Average Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }
                else if (Accomplishments > (num * 6) && (Accomplishments < 9 + (num * 6)))
                {
                    string s = "Good Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }
                else
                {
                    string s = "Excellent Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }

            }
            else
            {
                if (Accomplishments < (num * 9))
                {
                    string s = "Poor Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }
                else if (Accomplishments == (num * 9))
                {
                    string s = "Average Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }
                else if (Accomplishments > (num * 9) && (Accomplishments < 9 + (num * 9)))
                {
                    string s = "Good Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }
                else
                {
                    string s = "Excellent Performance" + ":" + Convert.ToString(dec) + "%";
                    l.Add(s);
                    return l;
                }
            }
        }

       public List<string> evaluation_totalperf_percent_updating_Grades()
       {
            List<string> L1 = _If.getallverifiedFiles();

            List<string> L2 = _Iemp.getallEmployeeAsync();

            int num = 0;

            foreach(string s2 in L2)
            {
                string[] str2 = s2.Split(':');
               

                if (!(str2[0].Equals("EXECUTIVE_DIRECTOR")))
                {
                    
                    if (str2[0].Equals("RESEARCHER") || str2[0].Equals("SENIOR_RESEARCHER"))
                    {
                                              
                        if (L1 != null)
                        {
                            List<string> L3 = new List<string>();
                            foreach (string s1 in L1)
                            {
                               
                                string[] str1 = s1.Split(':');

                                if (str2[6].Equals(str1[0]))
                                {
                                    L3.Add(str1[2]);
                                }
                            }

                            if (L3 != null)
                            {
                                if (L3.Count != 0)
                                {
                                    calculateresearcherGrades(Convert.ToInt32(str2[6]), L3);
                                }

                            }                          
                        }
                       
                    }
                    else
                    {
                        List<string> comm = _Icom.getverifiedadminComments(str2[6]);                       

                        calculateadminGrades(Convert.ToInt32(str2[6]), comm);
                        
                    }

                    num++;
                }                             
            }
            return autoevaluationCycle(num);
       }

        private void calculateresearcherGrades(int id, List<string> l3)
        {
            List<decimal> d = getresearcherGrade(id);

            decimal c = d[0];
            decimal c1 = d[1];
            decimal c2 = d[2];

            if(l3 != null)
            {
                foreach (string str in l3)
                {
                    if (str.Equals("DISSEMINATION"))
                    {
                        c++;
                    }
                    if (str.Equals("PUBLICATION"))
                    {
                        c1++;
                    }
                    else
                    {
                        c2++;
                    }
                }

                updateresearcherMarks(id, c, c1, c2);
            }
            
        }

        private void calculateadminGrades(int id, List<string> comm)
        {
            decimal d = getadminGrade(id);

            if (comm != null)
            {
                foreach(string s in comm)
                {
                    string[] str = s.Split(':');

                    if (str[1].Equals("COMPLEMENT"))
                    {
                        d++;
                    }
                    else
                    {
                        d--;
                    }
                    
                }

                updateadminComment(id, d);

            }

        }
    }

}
