﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public class filesRepo : IfilesRepository
    {
        protected readonly IConfiguration _config;
        protected readonly employeeRepository _Iemp;
        protected readonly IcommentsRepository _Icom;
        protected readonly IverificationRepository _Ive;

        public filesRepo(IConfiguration config, employeeRepository Iemp, IcommentsRepository Icom, IverificationRepository Ive)
        {
            _config = config;
            _Iemp = Iemp;
            _Icom = Icom;
            _Ive = Ive;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("SATRI_db_Connection"));
            }
        }

        private void updateverifiedFiles(string fid, string status)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spevaluationUpdate", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    SqlParameter I = new SqlParameter();
                    I.ParameterName = "@stat";
                    I.SqlDbType = SqlDbType.VarChar;
                    I.Value = status;

                    SqlParameter f = new SqlParameter();
                    f.ParameterName = "@fD";
                    f.SqlDbType = SqlDbType.VarChar;
                    f.Value = fid;

                    cmd.Parameters.Add(f);
                    cmd.Parameters.Add(I);

                    cmd.ExecuteNonQueryAsync();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public List<string> getallverifiedFiles()
        {
            List<string> l = new List<string>();

            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spgetallverifiedFiles", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());

                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            string str = Convert.ToString(r.GetInt32(0)) + ":" + r.GetString(1) + ":" + r.GetString(2);
                            updateverifiedFiles(r.GetString(1), "EVALUATED");
                            l.Add(str);
                        }

                    }

                    if (l.Count != 0)
                    {
                        conn.Close();
                        return l;
                    }
                    else
                    {
                        conn.Close();
                        return null;
                    }

                }
            }
            catch (Exception e)
            {
                throw e;

            }
        }


        public List<string> getForwardedFile(string receiver)
        {
            List<string> l = new List<string>();

            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spgetforwardedFiles", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter e = new SqlParameter();
                    e.ParameterName = "@recipient";
                    e.SqlDbType = SqlDbType.VarChar;
                    e.Value = receiver;

                    cmd.Parameters.Add(e);

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());

                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            string str = r.GetString(0) + ":" + r.GetString(1) + ":" + Convert.ToString(r.GetInt32(2)) + ":" + r.GetString(3);
                            int num = _Ive.UpdateFiles(r.GetString(3),r.GetInt32(2), receiver, "RECEIVED");
                            l.Add(str);
                        }

                    }

                    if (l.Count != 0)
                    {
                        conn.Close();
                        return l;
                    }
                    else
                    {
                        conn.Close();
                        return null;
                    }
                }

            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public int removeFile(string fileID)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spremoveFile", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter e = new SqlParameter();
                    e.ParameterName = "@fileid";
                    e.SqlDbType = SqlDbType.VarChar;
                    e.Value = fileID;

                    cmd.Parameters.Add(e);

                    cmd.ExecuteNonQuery();

                    conn.Close();
                    return 1;

                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
                return -1;

            }
        }

        public int uploadFile(int id, string fType, string fileName, int recipID)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {                 

                    if (recipID > 0)
                    {
                        SqlCommand cmd2 = new SqlCommand("spaddFile", (SqlConnection)conn);
                        cmd2.CommandType = CommandType.StoredProcedure;

                        conn.Open();
                        SqlParameter I = new SqlParameter();
                        I.ParameterName = "@senderId";
                        I.SqlDbType = SqlDbType.Int;
                        I.Value = id;

                        SqlParameter fid = new SqlParameter();
                        fid.ParameterName = "@F_ID";
                        fid.SqlDbType = SqlDbType.VarChar;
                        fid.Value = Convert.ToString(new Random().Next(9000, 100000) + id);

                        SqlParameter n = new SqlParameter();
                        n.ParameterName = "@F_Nam";
                        n.SqlDbType = SqlDbType.VarChar;
                        n.Value = fileName;

                        SqlParameter d = new SqlParameter();
                        d.ParameterName = "@cDate";
                        d.SqlDbType = SqlDbType.Date;
                        d.Value = DateTime.Today;

                        SqlParameter t = new SqlParameter();
                        t.ParameterName = "@F_Type";
                        t.SqlDbType = SqlDbType.VarChar;
                        t.Value = fType;

                        SqlParameter re = new SqlParameter();
                        re.ParameterName = "@F_Recipient";
                        re.SqlDbType = SqlDbType.VarChar;
                        re.Value = Convert.ToString(recipID);

                        cmd2.Parameters.Add(I);
                        cmd2.Parameters.Add(fid);
                        cmd2.Parameters.Add(n);
                        cmd2.Parameters.Add(d);
                        cmd2.Parameters.Add(t);
                        cmd2.Parameters.Add(re);

                        cmd2.ExecuteNonQuery();

                        int num = _Icom.comment(id, id, recipID, "Request to verify file", "FEEDBACK", 0);
                        conn.Close();
                        return 1;
                    }
                    else
                    {
                        return -1;
                    }

                }

            } catch (Exception e)
            {
                e.GetBaseException();
                return -1;
            }
        }

        public List<string> viewFiles(string id)
        {
            List<string> l = new List<string>();

            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spviewFile", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter e = new SqlParameter();
                    e.ParameterName = "@id";
                    e.SqlDbType = SqlDbType.Int;
                    e.Value = Convert.ToInt32(id);

                    cmd.Parameters.Add(e);

                    SqlDataReader r = cmd.EndExecuteReader(cmd.BeginExecuteReader());

                    while (r.Read())
                    {
                        if (r.HasRows)
                        {
                            string str = r.GetString(0) + ":" + r.GetString(1) + ":" + r.GetString(2) + ":" + r.GetString(3) + ":" + r.GetDateTime(4);
                            l.Add(str);
                        }
                       
                    }

                    if (l.Count != 0)
                    {
                        conn.Close();
                        return l;
                    }
                    else
                    {
                        conn.Close();
                        return null;
                    }
                }
            }
            catch (Exception e)
            {
                throw e;
               
            }
        }
    }
}
    

