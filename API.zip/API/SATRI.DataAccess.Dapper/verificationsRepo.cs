﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace SATRI.DataAccess.Dapper
{
    public class verificationsRepo : IverificationRepository
    {
        protected readonly IConfiguration _config;
        protected readonly employeeRepository _Iemp;
        protected readonly IcommentsRepository _Icomm;

        public verificationsRepo(IConfiguration config, employeeRepository Iemp, IcommentsRepository Icomm)
        {
            _config = config;
            _Iemp = Iemp;
            _Icomm = Icomm;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("SATRI_db_Connection"));
            }
        }

        public int UpdateVerifiedAccount(int id, int veriferID)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spUpdateAccount", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter e = new SqlParameter();
                    e.ParameterName = "@id";
                    e.SqlDbType = SqlDbType.Int;
                    e.Value = id;

                    cmd.Parameters.Add(e);

                    cmd.ExecuteNonQuery();

                    //Notify the person whose account has neen verified              
                    int num = _Icomm.comment(veriferID, veriferID, id, "Account has been verified", "FEEDBACK", 0);

                    List<string> employ = _Iemp.getEmployeebyIdAsync(id);
                    if (employ[0].Equals("ADMINISTRATOR"))
                    {
                        insertadminGrade(id);
                    }
                    else
                    {
                        insertResearcherGrade(id);
                    }
                  
                    conn.Close();
                    return 1;
                }

            }catch(Exception e)
            {
                e.GetBaseException();
                return -1;
            }
        }


        private void insertResearcherGrade(int eid)
        {

            try
            {
                using (IDbConnection conn = Connection)
                {

                    SqlCommand cmdn = new SqlCommand("insertresearcherGrade", (SqlConnection)conn);
                    cmdn.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    SqlParameter n = new SqlParameter();
                    n.ParameterName = "@id";
                    n.SqlDbType = SqlDbType.Int;
                    n.Value = eid;

                    cmdn.Parameters.Add(n);

                    cmdn.ExecuteNonQuery();

                    conn.Close();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private void insertadminGrade(int eid)
        {

            try
            {
                using (IDbConnection conn = Connection)
                {

                    SqlCommand cmdm = new SqlCommand("insertadminGrade", (SqlConnection)conn);
                    cmdm.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    SqlParameter m = new SqlParameter();
                    m.ParameterName = "@id";
                    m.SqlDbType = SqlDbType.Int;
                    m.Value = eid;

                    cmdm.Parameters.Add(m);


                    cmdm.ExecuteNonQuery();

                    conn.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public int UpdateVerifiedComments(int C_ID, string adminId, string receiverId)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spverifiedAdminComments", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter e = new SqlParameter();
                    e.ParameterName = "@CID";
                    e.SqlDbType = SqlDbType.VarChar;
                    e.Value = Convert.ToString(C_ID);

                    cmd.Parameters.Add(e);

                    cmd.ExecuteNonQuery();


                    int num = _Icomm.comment(Convert.ToInt32(receiverId), Convert.ToInt32(receiverId), Convert.ToInt32(adminId), "Comment has been verified", "FEEDBACK", 0);

                    conn.Close();
                    return 1;
                }
            }
            catch(Exception e)
            {
                e.GetBaseException();
                return -1;
            }

        }

        public int UpdateFiles(string fileid, int senderid, string receiverId, string Filestatus)
        {
            try
            {
                using (IDbConnection conn = Connection)
                {
                    SqlCommand cmd = new SqlCommand("spUpdatefile", (SqlConnection)conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    conn.Open();
                    SqlParameter e = new SqlParameter();
                    e.ParameterName = "@fD";
                    e.SqlDbType = SqlDbType.VarChar;
                    e.Value = fileid;

                    SqlParameter sI = new SqlParameter();
                    sI.ParameterName = "@senderId";
                    sI.SqlDbType = SqlDbType.Int;
                    sI.Value = senderid;

                    SqlParameter r = new SqlParameter();
                    r.ParameterName = "@receiverId";
                    r.SqlDbType = SqlDbType.VarChar;
                    r.Value = receiverId;

                    SqlParameter s = new SqlParameter();
                    s.ParameterName = "@stat";
                    s.SqlDbType = SqlDbType.VarChar;
                    s.Value = Filestatus;

                    cmd.Parameters.Add(e);
                    cmd.Parameters.Add(sI);
                    cmd.Parameters.Add(r);
                    cmd.Parameters.Add(s);

                    cmd.ExecuteNonQuery();

                    int num = _Icomm.comment(Convert.ToInt32(receiverId), Convert.ToInt32(receiverId), senderid, "file has been " + Filestatus , "FEEDBACK", 0);

                    conn.Close();
                    return 1;

                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
                return -1;

            }
        }
    }
}
