﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SATRI.Services
{
    public interface ISATRI_service
    {
        //employees
        List<string> getEmployeebyIdAsync(int id);
        List<string> getallEmployeeAsync();
        int RegisterAsync(string title, string firstname, string surname, string userType, string contact, string email, string password);
        List<string> getEmpDetailsAsync(string email, string password);
        string[] Login(string email, string password);
        int updateProfile(string contact, string email, string password, int ID);
        List<string> getEmployeeByUserType(string userT);
        List<string> getaccountbyUserType(string userT);

        //files
        int removeFile(string fileID);//unforward the file
        List<string> viewFiles(string id);
        List<string> getForwardedFile(string receiver);
        int uploadFile(int id, string fType, string fileName, int RecipID);

        //verifications
        int UpdateVerifiedAccount(int id, int veriferID);
        int UpdateFiles(string fileid, int senderid, string receiverId, string filestatus);
        int UpdateVerifiedComments(int C_ID, string adminId, string receiverId);

        //comments
        int comment(int C_ID, int ID, int Recipient, string Descrip, string comment_Type, int compReceiver);
        List<string> viewCommentAboutme(string id);
        List<string> viewComment_I_Made(string id);
        List<string> viewCommentaboutAdministrator(int id);
        List<string> getFeedback(string id);
        int getcommentNo(string id);
        int getfeedbackNo(string id);

        //evaluation
        decimal gettotalperformanceGrade();
        List<decimal> getresearcherGrade(int id);
        decimal getadminGrade(int id);
        List<string> evaluation_totalperf_percent_updating_Grades();

    }
}
