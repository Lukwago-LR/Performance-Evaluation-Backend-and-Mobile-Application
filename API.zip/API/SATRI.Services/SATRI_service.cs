﻿using SATRI.DataAccess.Dapper;
using System;
using System.Collections.Generic;
using System.Text;

namespace SATRI.Services
{
    public class SATRI_service : ISATRI_service
    {
        //dependence injection
        protected readonly employeeRepository Iemp;
        protected readonly accountRepository Iacc;
        protected readonly IfilesRepository If;
        protected readonly IverificationRepository Iv;
        protected readonly IcommentsRepository Icom;
        protected readonly IevaluationsRepository Ieval;

        public SATRI_service(employeeRepository _Iemp, accountRepository _Iacc, IfilesRepository _If, IverificationRepository _Iv, IcommentsRepository _Icom, IevaluationsRepository _Ieval)
        {
            Iemp = _Iemp;
            Iacc = _Iacc;
            If = _If;
            Iv = _Iv;
            Icom = _Icom;
            Ieval = _Ieval;
        }

        public int comment(int C_ID, int ID, int Recipient, string Descrip, string comment_Type, int compReceiver)
        {
            return Icom.comment(C_ID, ID, Recipient, Descrip, comment_Type, compReceiver);
        }

        public List<string> getallEmployeeAsync()
        {
           return Iemp.getallEmployeeAsync();
        }

        public int getcommentNo(string id)
        {
            return Icom.getcommentNo(id);
        }

        public List<string> getEmpDetailsAsync(string email, string password)
        {
            return Iacc.getEmpDetailsAsync(email,password);
        }

        public List<string> getEmployeebyIdAsync(int id)
        {
            return Iemp.getEmployeebyIdAsync(id);
        }

        public List<string> getFeedback(string id)
        {
            return Icom.getFeedback(id);
        }

        public int getfeedbackNo(string id)
        {
            return Icom.getfeedbackNo(id);
        }

        public List<string> getForwardedFile(string receiver)
        {
            return If.getForwardedFile(receiver);
        }

        public string[] Login(string email, string password)
        {
           return  Iacc.Login(email, password);
        }

        public int RegisterAsync(string title, string firstname, string surname, string userType, string contact, string email, string password)
        {
            return Iacc.RegisterAsync(title,firstname,surname,userType,contact,email,password);
        }

        public int removeFile(string fileID)
        {
            return If.removeFile(fileID);
        }

        public int updateProfile(string contact, string email, string password, int ID)
        {
            return Iacc.updateProfile(contact, email, password, ID);
        }

        public int UpdateVerifiedAccount(int id, int veriferID)
        {
            return Iv.UpdateVerifiedAccount(id, veriferID);
        }

        public int UpdateVerifiedComments(int C_ID, string adminId, string receiverId)
        {
            return Iv.UpdateVerifiedComments(C_ID, adminId, receiverId);
        }

        public int UpdateFiles(string fileid, int senderid, string receiverId, string filestatus)
        {
            return Iv.UpdateFiles(fileid, senderid, receiverId, filestatus);
        }

        public int uploadFile(int id, string fType, string fileName, int RecipID)
        {
            return If.uploadFile(id, fType, fileName, RecipID);
        }

        public List<string> viewCommentaboutAdministrator(int id)
        {
            return Icom.viewCommentaboutAdministrator(id);
        }

        public List<string> viewCommentAboutme(string id)
        {
            return Icom.viewCommentAboutme(id);
        }

        public List<string> viewComment_I_Made(string id)
        {
            return Icom.viewComment_I_Made(id);
        }

        public List<string> viewFiles(string id)
        {
            return If.viewFiles(id);
        }

        public List<string> getEmployeeByUserType(string userT)
        {
            return Iemp.getEmployeeByUserType(userT);
        }

        public decimal gettotalperformanceGrade()
        {
            return Ieval.gettotalperformanceGrade();
        }

        public List<decimal> getresearcherGrade(int id)
        {
            return Ieval.getresearcherGrade(id);
        }

        public decimal getadminGrade(int id)
        {
            return Ieval.getadminGrade(id);
        }

        public List<string> evaluation_totalperf_percent_updating_Grades()
        {
            return Ieval.evaluation_totalperf_percent_updating_Grades();
        }

        public List<string> getaccountbyUserType(string userT)
        {
            return Iacc.getaccountbyUserType(userT);
        }
    }

}
