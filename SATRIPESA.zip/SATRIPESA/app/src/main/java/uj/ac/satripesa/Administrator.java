package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationBuilderWithBuilderAccessor;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.arturogutierrez.Badges;
import com.github.arturogutierrez.BadgesNotSupportedException;

public class Administrator extends AppCompatActivity {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";

    private Button viewAF;
    private Button makeAF;
    private Button viewAC;
    private TextView feNo;
    private TextView comNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_administrator);

        final String myID = getIntent().getStringExtra("adminID");

        viewAF = findViewById(R.id.viewfeedTextviewAdministrator);
        makeAF = findViewById(R.id.makefeedTextviewAdministrator);
        viewAC = findViewById(R.id.viewcommentTextviewAdministrator);

        feNo = findViewById(R.id.fedNotifyadmin);
        comNo = findViewById(R.id.commNotifyAd);



        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel channel = new NotificationChannel("myNotification", "notificationChannel", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);

            NotificationChannel channel2 = new NotificationChannel("myComment", "commentChannel", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager2 = getSystemService(NotificationManager.class);
            manager2.createNotificationChannel(channel2);
        }


        setfeedNo(myID);
        setcommnetNo(myID);

        viewAF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openviewAF(myID);
            }
        });

        makeAF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openmakeAF(myID);
            }
        });

        viewAC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openviewAC(myID);
            }
        });

    }

    private void setcommnetNo(String myID) {

        RequestQueue queue = Volley.newRequestQueue(getBaseContext());

        String url = baseurl+"getcommentNo?id=" + myID;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        comNo.setText(response);
                        if(!(response.equals("0"))){
                            NotificationCompat.Builder builder = new NotificationCompat.Builder(Administrator.this, "myComment");
                            builder.setContentTitle("SATRIPEep NEW NOTIFICATION");
                            builder.setContentText("You have new comments");
                            builder.setSmallIcon(R.drawable.satrifavi);
                            builder.setAutoCancel(false);

                            NotificationManagerCompat managerCompat =  NotificationManagerCompat.from(Administrator.this);
                            managerCompat.notify(2,builder.build());

                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(Administrator.this,"feed no failed",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);


    }

    private void setfeedNo(String myID) {
        RequestQueue queue = Volley.newRequestQueue(getBaseContext());

        String url = baseurl+"getfeedbackNo?id=" + myID;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        feNo.setText(response);
                       if(!(response.equals("0"))){
                           NotificationCompat.Builder builder = new NotificationCompat.Builder(Administrator.this, "myNotification");
                           builder.setContentTitle("SATRIPEep NEW NOTIFICATION");
                           builder.setContentText("You have new feedback");
                           builder.setSmallIcon(R.drawable.satrifavi);
                           builder.setAutoCancel(false);

                           NotificationManagerCompat managerCompat =  NotificationManagerCompat.from(Administrator.this);
                           managerCompat.notify(1,builder.build());
                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"comment no failed",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);
    }

    private void openviewAF(String id) {
        Intent intent = new Intent(this, viewfeedAll.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }

    private void openmakeAF(String id) {
        Intent intent = new Intent(this, sendfeedAll.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }

    private void openviewAC(String id) {
        Intent intent = new Intent(this, viewcommentsAboutmeAdmin.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }
}