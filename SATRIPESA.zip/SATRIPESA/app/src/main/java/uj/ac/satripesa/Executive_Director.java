package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Executive_Director extends AppCompatActivity {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";

    private Button viewEF;
    private Button makeEF;
    private TextView feNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_executive__director);

        final String myID = getIntent().getStringExtra("executiveID");

        feNo = findViewById(R.id.feedNotifyExe);
        viewEF = findViewById(R.id.viewfeedTextviewExecutive);
        makeEF = findViewById(R.id.makefeedTextviewExecutive);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel3 = new NotificationChannel("myexeNotification", "exeChannel", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager3 = getSystemService(NotificationManager.class);
            manager3.createNotificationChannel(channel3);
        }

        setfeedNo(myID);

        viewEF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openviewEF(myID);
            }
        });

        makeEF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openmakeEF(myID);
            }
        });


    }

    private void setfeedNo(String myID) {
        RequestQueue queue = Volley.newRequestQueue(getBaseContext());

        String url = baseurl+"getfeedbackNo?id=" + myID;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        feNo.setText(response);

                        if(!(response.equals("0"))){
                            NotificationCompat.Builder builder = new NotificationCompat.Builder(Executive_Director.this, "myexeNotification");
                            builder.setContentTitle("SATRIPEep NEW NOTIFICATION");
                            builder.setContentText("You have new feedback");
                            builder.setSmallIcon(R.drawable.satrifavi);
                            builder.setAutoCancel(true);

                            NotificationManagerCompat managerCompat =  NotificationManagerCompat.from(Executive_Director.this);
                            managerCompat.notify(3,builder.build());
                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"comment no failed",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);
    }

    private void openmakeEF(String id) {
        Intent intent = new Intent(this, sendfeedAll.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }

    private void openviewEF(String id) {
        Intent intent = new Intent(this, viewfeedAll.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }
}