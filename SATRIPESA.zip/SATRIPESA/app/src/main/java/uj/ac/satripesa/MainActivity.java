package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


public class MainActivity extends AppCompatActivity {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";
    private Button loginBtn;
    private Button goToRegister;
    private EditText passwordTxt;
    private EditText emailTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //find our button and the text fields
        loginBtn = findViewById(R.id.finishReg);
        passwordTxt = findViewById(R.id.password);
        emailTxt = findViewById(R.id.email);
        goToRegister = findViewById(R.id.signUp);

        goToRegister.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                openRegister();
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {

                if (!(emailTxt.getText().equals("") ) && !(passwordTxt.getText().equals(""))){

                    // Instantiate the RequestQueue.
                    RequestQueue queue = Volley.newRequestQueue(getBaseContext());

                    String url = baseurl+"Login?email="+ emailTxt.getText() + "&&password="+ passwordTxt.getText();                    // Request a string response from the provided URL.
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {

                                    if(response.length() < 20){
                                        Toast. makeText(getApplicationContext(), "Wrong password or email", Toast. LENGTH_SHORT).show();
                                    }
                                    else{
                                        String str = response.replaceAll("[^a-zA-Z0-9(',')('_')]", "");
                                        String[] strDetails = str.split(",");

                                            if (strDetails == null)
                                            {
                                                Toast. makeText(getApplicationContext(), "Wrong password or email", Toast. LENGTH_SHORT).show();
                                            }
                                            else if (strDetails[2].equals("VERIFIED"))
                                            {

                                                if (strDetails[1].equals("EXECUTIVE_DIRECTOR"))
                                                {
                                                    openExecutiveDirector(strDetails[0]);
                                                }
                                                else if (strDetails[1].equals("SENIOR_RESEARCHER"))
                                                {
                                                    openSeniorResearcher(strDetails[0]);
                                                }
                                                else if (strDetails[1].equals("RESEARCHER"))
                                                {
                                                    openResearcher(strDetails[0]);
                                                }
                                                else if (strDetails[1].equals("ADMINISTRATOR"))
                                                {
                                                    openAdministrator(strDetails[0]);
                                                }
                                            }
                                            else if (strDetails[2].equals("UNVERIFIED"))
                                            {
                                                Toast. makeText(getApplicationContext(), "not verified", Toast. LENGTH_SHORT).show();
                                            }
                                            else
                                            {
                                                Toast. makeText(getApplicationContext(), "wrong password or email", Toast. LENGTH_SHORT).show();
                                            }
                                    }
                                }
                            },new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Toast. makeText(getApplicationContext(),"internet connection failure",Toast. LENGTH_SHORT).show();
                        }
                    });
                    queue.add(stringRequest);

                }
                else{

                    Toast. makeText(getApplicationContext(), "Wrong password or email", Toast. LENGTH_SHORT).show();
                }

            }
        } );
    }

    private void openRegister() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

    private void openSeniorResearcher(String id) {
        Intent intent = new Intent(this, Senior_Researcher.class);
        intent.putExtra("seniorRID", id);
        startActivity(intent);
    }

    private void openResearcher(String id) {
        Intent intent = new Intent(this, Researcher.class);
        intent.putExtra("RID", id);
        startActivity(intent);
    }

    private void openExecutiveDirector(String id) {
        Intent intent = new Intent(this, Executive_Director.class);
        intent.putExtra("executiveID", id);
        startActivity(intent);
    }

    private void openAdministrator(String id) {
        Intent intent = new Intent(this, Administrator.class);
        intent.putExtra("adminID", id);
        startActivity(intent);
    }

}