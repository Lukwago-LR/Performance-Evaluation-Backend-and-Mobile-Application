package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class RegisterActivity extends AppCompatActivity {

   private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";

   private Button regF;
    private EditText fN;
    private EditText sN;
    private EditText regE;
    private EditText regPass1;
    private  EditText cont;
    private EditText regPass2;
    private Spinner sTitle;
    private Spinner userT;
    private String strTitle;
    private String strType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        regF = findViewById(R.id.regFinish);
        fN = findViewById(R.id.firstName);
        sN = findViewById(R.id.surName);
        cont = findViewById(R.id.contact);
        regE = findViewById(R.id.regEmail);
        regPass1 = findViewById(R.id.regConfirmPassword);
        regPass2 = findViewById(R.id.regPassword);
        sTitle = findViewById(R.id.title);
        userT = findViewById(R.id.userType);

        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.userTitles, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sTitle.setAdapter(adapter);

        sTitle.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sTitle.setOnItemSelectedListener(this);
                strTitle = parent.getItemAtPosition(parent.getFirstVisiblePosition()).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,R.array.Types, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        userT.setAdapter(adapter2);

        userT.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                userT.setOnItemSelectedListener(this);
                strType = parent.getItemAtPosition(parent.getFirstVisiblePosition()).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        regF.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                if (!(regPass1.getText().toString().trim().equals(regPass2.getText().toString().trim())))
                {
                    Toast.makeText(getApplicationContext(),"password mismatch",Toast. LENGTH_SHORT).show();
                }
                else
                {

                    // Instantiate the RequestQueue.
                    RequestQueue queue = Volley.newRequestQueue(getBaseContext());

                    String url = baseurl+"RegisterAsync?title=" + strTitle + "&&firstname=" + fN.getText() + "&&surname=" + sN.getText() + "&&userType=" + strType + "&&contact=" + cont.getText() + "&&email=" + regE.getText() + "&&password=" + regPass1.getText();

                    // Request a string response from the provided URL.
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {

                                    int num = Integer.parseInt(response);

                                    if (num == 1)
                                    {
                                        openMainActivity();
                                    }
                                    else if (num == -1)
                                    {
                                        Toast.makeText(getApplicationContext(),"Something went wrong, please try again later",Toast. LENGTH_SHORT).show();
                                    }
                                    else if (num == 0)
                                    {
                                        Toast.makeText(getApplicationContext(),"The user already exists",Toast. LENGTH_SHORT).show();
                                    }


                                }
                            },new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Toast. makeText(getApplicationContext(),"registration unsuccessful",Toast. LENGTH_SHORT).show();
                        }
                    });
                    queue.add(stringRequest);

                }


            }
        });

    }


    private void openMainActivity() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}