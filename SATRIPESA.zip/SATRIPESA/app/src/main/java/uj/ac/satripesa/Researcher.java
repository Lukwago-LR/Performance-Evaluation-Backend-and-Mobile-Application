package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Researcher extends AppCompatActivity {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";
    private Button viewRF;
    private Button makeRF;
    private Button viewRC;
    private Button makeRC;
    private TextView feNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_researcher);

        feNo = findViewById(R.id.feedNotifyR);
        viewRF = findViewById(R.id.viewfeedTextviewResearcher);
        makeRF = findViewById(R.id.makefeedTextviewResearcher);
        viewRC = findViewById(R.id.viewcommentTextviewResearcher);
        makeRC = findViewById(R.id.makecommentTextviewResearcher);

        final String myID = getIntent().getStringExtra("RID");

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel4 = new NotificationChannel("myrNotification", "rChannel", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager4 = getSystemService(NotificationManager.class);
            manager4.createNotificationChannel(channel4);
        }


        setfeedNo(myID);

        viewRF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openviewRF(myID);
            }
        });

        makeRF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openmakeRF(myID);
            }
        });

        viewRC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openviewRC(myID);
            }
        });

        makeRC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openmakeRC(myID,"RESEARCHER");
            }
        });
    }

    private void setfeedNo(String myID) {
        RequestQueue queue = Volley.newRequestQueue(getBaseContext());

        String url = baseurl+"getfeedbackNo?id=" + myID;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        feNo.setText(response);

                        if(!(response.equals("0"))){
                            NotificationCompat.Builder builder = new NotificationCompat.Builder(Researcher.this, "myrNotification");
                            builder.setContentTitle("SATRIPEep NEW NOTIFICATION");
                            builder.setContentText("You have new feedback");
                            builder.setSmallIcon(R.drawable.satrifavi);
                            builder.setAutoCancel(true);

                            NotificationManagerCompat managerCompat =  NotificationManagerCompat.from(Researcher.this);
                            managerCompat.notify(4,builder.build());
                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"comment no failed",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);
    }

    private void openviewRF(String id) {
        Intent intent = new Intent(this, viewfeedAll.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }

    private void openmakeRF(String id) {
        Intent intent = new Intent(this, sendfeedAll.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }

    private void openviewRC(String id) {
        Intent intent = new Intent(this, viewMycommentsResearcher.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }

    private void openmakeRC(String id,String type) {
        Intent intent = new Intent(this, commentResearcher.class);
        intent.putExtra("theID",id);
        intent.putExtra("theType",type);
        startActivity(intent);
    }
}