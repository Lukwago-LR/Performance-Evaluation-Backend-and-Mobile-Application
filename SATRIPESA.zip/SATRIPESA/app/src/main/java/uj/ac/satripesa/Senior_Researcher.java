package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class Senior_Researcher extends AppCompatActivity {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";
    private Button viewF;
    private Button makeF;
    private Button viewC;
    private Button makeC;
    private TextView feNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senior__researcher);

        final String myID = getIntent().getStringExtra("seniorRID");

        feNo = findViewById(R.id.feedNotifySR);
        viewF = findViewById(R.id.viewfeedTextview);
        makeF = findViewById(R.id.makefeedTextview);
        viewC = findViewById(R.id.viewcommentTextview);
        makeC = findViewById(R.id.makecommentTextview);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel5 = new NotificationChannel("mysrNotification", "srChannel", NotificationManager.IMPORTANCE_HIGH);
            NotificationManager manager5 = getSystemService(NotificationManager.class);
            manager5.createNotificationChannel(channel5);
        }

        setfeedNo(myID);

        viewF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openviewF(myID);
            }
        });

        makeF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openmakeF(myID);
            }
        });

        viewC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openviewC(myID);
            }
        });

        makeC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openmakeC(myID,"SENIOR_RESEARCHER");
            }
        });
    }

    private void setfeedNo(String myID) {
        RequestQueue queue = Volley.newRequestQueue(getBaseContext());

        String url = baseurl+"getfeedbackNo?id=" + myID;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        feNo.setText(response);

                        if(!(response.equals("0"))){
                            NotificationCompat.Builder builder = new NotificationCompat.Builder(Senior_Researcher.this, "mysrNotification");
                            builder.setContentTitle("SATRIPEep NEW NOTIFICATION");
                            builder.setContentText("You have new feedback");
                            builder.setSmallIcon(R.drawable.satrifavi);
                            builder.setAutoCancel(true);

                            NotificationManagerCompat managerCompat =  NotificationManagerCompat.from(Senior_Researcher.this);
                            managerCompat.notify(5,builder.build());
                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"comment no failed",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);
    }


    private void openviewF(String id) {
        Intent intent = new Intent(this, viewfeedAll.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }
    private void openmakeF(String id) {
        Intent intent = new Intent(this, sendfeedAll.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }
    private void openviewC(String id) {
        Intent intent = new Intent(this, viewMycommentsResearcher.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }
    private void openmakeC(String id,String type) {
        Intent intent = new Intent(this, sendfeedAll.class);
        intent.putExtra("theID",id);
        startActivity(intent);
    }
}