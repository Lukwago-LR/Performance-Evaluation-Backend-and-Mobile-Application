package uj.ac.satripesa;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class admincommentaboutAdapter extends RecyclerView.Adapter<admincommentaboutAdapter.myviewadminHolder> {

    private String[] recipAdmin;
    private String[] statAdmin;
    private String[] descripAdmin;
    private String[] typsAdmin;
    private String[] dsAdmin;
    private String[] nosAdmin;

    private Context context;

    public admincommentaboutAdapter(Context contextA, String []recipsA, String[] statA, String[] descripA, String[] typA, String[] dateA, String[] noA){
        recipAdmin = recipsA;
        statAdmin = statA;
        descripAdmin = descripA;
        typsAdmin = typA;
        dsAdmin = dateA;
        nosAdmin = noA;
    }

    @NonNull
    @Override
    public myviewadminHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.commentsaboutadminrecycle,parent,false);
        return new myviewadminHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myviewadminHolder holder, int position) {

        holder.commentNoA.setText(nosAdmin[position]);
        holder.recipientA.setText(recipAdmin[position]);
        holder.statusA.setText(statAdmin[position]);
        holder.desA.setText(descripAdmin[position]);
        holder.typeA.setText(typsAdmin[position]);
        holder.dateA.setText(dsAdmin[position]);

    }

    @Override
    public int getItemCount() {
        return recipAdmin.length;
    }

    public class myviewadminHolder extends RecyclerView.ViewHolder{

        TextView commentNoA;
        TextView recipientA;
        TextView statusA;
        TextView desA;
        TextView typeA;
        TextView dateA;

        public myviewadminHolder(@NonNull View itemView) {
            super(itemView);
            commentNoA = itemView.findViewById(R.id.ViewNoAdmin);
            recipientA = itemView.findViewById(R.id.viewRecipientA);
            statusA = itemView.findViewById(R.id.viewStatusAdmin);
            desA = itemView.findViewById(R.id.viewDescripAdmin);
            typeA = itemView.findViewById(R.id.viewTypeAdmin);
            dateA = itemView.findViewById(R.id.viewDateAdmin);
        }
    }
}
