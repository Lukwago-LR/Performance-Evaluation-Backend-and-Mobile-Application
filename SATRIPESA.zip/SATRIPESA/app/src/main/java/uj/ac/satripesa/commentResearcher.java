package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class commentResearcher extends AppCompatActivity  {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";
    private Spinner comType;
    private Spinner recip;
    private Spinner comAbt;
    private EditText comDes;
    private Button comment;
    private String recipSpiner;
    private String abtSpiner;
    private String typSpiner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment_researcher);

        final String myID = getIntent().getStringExtra("theID");

        final String myType = getIntent().getStringExtra("theType");

        comType = findViewById(R.id.commNotifyAd);
        recip = findViewById(R.id.feedmakeSpiner);
        comAbt = findViewById(R.id.textView4);
        comDes = findViewById(R.id.textView5);
        comment = findViewById(R.id.editTexttired);

        final ArrayAdapter<CharSequence> adapterCom = ArrayAdapter.createFromResource(getApplicationContext(),R.array.commentTypes, android.R.layout.simple_spinner_item);
        adapterCom.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        comType.setAdapter(adapterCom);

        comType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                typSpiner = parent.getItemAtPosition(parent.getFirstVisiblePosition()).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        allEmployees(myType);
        fillAdmina();

        comment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RequestQueue queue = Volley.newRequestQueue(getBaseContext());
                String url = baseurl + "getallEmployeeAsync";

                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                JSONArray jsonArray = null;
                                try {

                                    if(response.length()<20){
                                        Toast. makeText(getApplicationContext(), "Failure to retrieve employees", Toast. LENGTH_SHORT).show();
                                    }else{

                                        ArrayList<String> list = new ArrayList<>();
                                        jsonArray = new JSONArray(response);

                                        if (jsonArray != null) {
                                            int len = jsonArray.length();
                                            for (int i = 0; i < len; i++) {
                                                list.add(jsonArray.get(i).toString());
                                            }

                                            int recipientID = 0;
                                            String aboutID ="";
                                            for(String str : list){
                                                String[] sAll = str.split(":");

                                                if(recipSpiner.contains(sAll[1]) && recipSpiner.contains(sAll[2])){
                                                    recipientID = Integer.parseInt(sAll[6]);
                                                }

                                                if(abtSpiner.contains(sAll[1]) && abtSpiner.contains(sAll[2])){
                                                    aboutID = sAll[6];

                                                }
                                            }

                                            if(aboutID != "" && recipientID != 0){

                                                finallyComment(Integer.parseInt(myID), Integer.parseInt(myID), recipientID, comDes.getText().toString(), typSpiner, aboutID);

                                            }else{
                                                Toast. makeText(getApplicationContext(), "Failure to retrieve employee ids", Toast. LENGTH_SHORT).show();
                                            }

                                        }
                                    }

                                } catch (JSONException e) {
                                    Toast. makeText(getApplicationContext(), "Json error", Toast. LENGTH_SHORT).show();
                                }

                            }
                        },new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast. makeText(getApplicationContext(),"Volley Error",Toast. LENGTH_SHORT).show();
                    }
                });
                queue.add(stringRequest);

            }
        });
    }

    private void finallyComment(int cid, int sid, int rid, String d, String com, String ab) {
        RequestQueue queue = Volley.newRequestQueue(getBaseContext());

        String url = baseurl+"comment?C_ID=" + cid + "&&ID=" + sid + "&&Recipient=" + rid + "&&Descrip=" + d + "&&comment_Type=" + com + "&&compReceiver=" + ab;

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        int num = Integer.parseInt(response);

                        if (num == 1)
                        {
                            Toast.makeText(getApplicationContext(),"Comment Received",Toast. LENGTH_SHORT).show();
                        }
                        else if (num == -1)
                        {
                            Toast.makeText(getApplicationContext(),"Something went wrong, please try again",Toast. LENGTH_SHORT).show();
                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),error.toString(),Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);

    }

    private void allEmployees(final String type) {
        RequestQueue queue = Volley.newRequestQueue(getBaseContext());
        String url = baseurl + "getallEmployeeAsync";


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        JSONArray jsonArray = null;
                        try {

                            if(response.length()<20){
                                Toast. makeText(getApplicationContext(), "Failure to retrieve employees", Toast. LENGTH_SHORT).show();
                            }else{

                                ArrayList<String> list = new ArrayList<>();
                                jsonArray = new JSONArray(response);

                                if (jsonArray != null) {
                                    int len = jsonArray.length();
                                    for (int i = 0; i < len; i++) {
                                        list.add(jsonArray.get(i).toString());
                                    }

                                    ArrayList<String> list2 = new ArrayList<>();
                                    for(String str : list){
                                        String[] sAll = str.split(":");
                                        if(type.equals("SENIOR_RESEARCHER")){
                                            if(sAll[0].equals("EXECUTIVE_DIRECTOR")){
                                                list2.add(sAll[1]+" " +sAll[2]);
                                            }
                                        }else{

                                            if(sAll[0].equals("SENIOR_RESEARCHER") ){
                                                list2.add(sAll[1]+" " +sAll[2]);
                                            }
                                        }

                                    }

                                    ArrayAdapter<String> adapter2 = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item,list2);
                                    adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                    recip.setAdapter(adapter2);

                                    recip.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                            recip.setOnItemSelectedListener(this);
                                            recipSpiner = parent.getItemAtPosition(parent.getFirstVisiblePosition()).toString();
                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parent) {

                                        }
                                    });

                                }
                            }

                        } catch (JSONException e) {
                            Toast. makeText(getApplicationContext(), "Json error", Toast. LENGTH_SHORT).show();
                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"Volley Error",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);

    }
    private void fillAdmina() {
        RequestQueue queue = Volley.newRequestQueue(getBaseContext());
        String url = baseurl + "getallEmployeeAsync";


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        JSONArray jsonArray = null;
                        try {

                            if(response.length()<20){
                                Toast. makeText(getApplicationContext(), "Failure to retrieve employees", Toast. LENGTH_SHORT).show();
                            }else{

                                ArrayList<String> list = new ArrayList<>();
                                jsonArray = new JSONArray(response);

                                if (jsonArray != null) {
                                    int len = jsonArray.length();
                                    for (int i = 0; i < len; i++) {
                                        list.add(jsonArray.get(i).toString());
                                    }

                                    ArrayList<String> list2 = new ArrayList<>();
                                    for(String str : list){
                                        String[] sAll = str.split(":");

                                        if(sAll[0].equals("ADMINISTRATOR")){
                                            list2.add(sAll[1]+" " +sAll[2]);
                                        }
                                    }

                                    ArrayAdapter<String> adapterAbt = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item,list2);
                                    adapterAbt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                    comAbt.setAdapter(adapterAbt);

                                    comAbt.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                            comAbt.setOnItemSelectedListener(this);
                                            abtSpiner = parent.getItemAtPosition(parent.getFirstVisiblePosition()).toString();

                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parent) {

                                        }
                                    });

                                }
                            }

                        } catch (JSONException e) {
                            Toast. makeText(getApplicationContext(), "Json error", Toast. LENGTH_SHORT).show();
                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"Volley Error",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);

    }
}