package uj.ac.satripesa;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class recyclerviewAdapter extends RecyclerView.Adapter<recyclerviewAdapter.myviewHolder> {

    private String[] recip;
    private String[] abtW;
    private String[] stat;
    private String[] descrip;
    private String[] typs;
    private String[] ds;
    private String[] nos;

    private Context context;


    public recyclerviewAdapter(Context cont, String[] recipient, String[] abt, String[] status, String[] description, String[] types, String[] dates, String[] numbers){

        context = cont;
        recip = recipient;
        abtW = abt;
        stat = status;
        descrip = description;
        typs = types;
        ds = dates;
        nos = numbers;

    }

    @NonNull
    @Override
    public myviewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.viewmycommentsrecycler,parent,false);
        return new myviewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myviewHolder holder, int position) {
        holder.commentNo.setText(nos[position]);
        holder.recipient.setText(recip[position]);
        holder.about.setText(abtW[position]);
        holder.status.setText(stat[position]);
        holder.desV.setText(descrip[position]);
        holder.type.setText(typs[position]);
        holder.date.setText(ds[position]);
    }

    @Override
    public int getItemCount() {
        return recip.length;
    }

    public class myviewHolder extends RecyclerView.ViewHolder{

        TextView commentNo;
        TextView recipient;
        TextView about;
        TextView status;
        TextView desV;
        TextView type;
        TextView date;

        public myviewHolder(@NonNull View itemView) {
            super(itemView);
            commentNo = itemView.findViewById(R.id.ViewNo);
            recipient = itemView.findViewById(R.id.viewRecipientA);
            about = itemView.findViewById(R.id.viewAbout);
            status = itemView.findViewById(R.id.viewStatus);
            desV = itemView.findViewById(R.id.viewDescrip);
            type = itemView.findViewById(R.id.viewType);
            date = itemView.findViewById(R.id.viewDate);
        }
    }


}
