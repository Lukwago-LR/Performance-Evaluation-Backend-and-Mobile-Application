package uj.ac.satripesa;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class recycleviewFeed extends RecyclerView.Adapter<recycleviewFeed.myViewHolder> {

    private Context context;
    private String senderF[];
    private String descripF[];
    private String dateF[];
    private String noF[];

    public recycleviewFeed(Context contF, String[] sendF, String[] descF, String[] dF, String[] nF){
        context=contF;
        senderF=sendF;
        descripF=descF;
        dateF=dF;
        noF=nF;

    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.viewfeedbackrecycle,parent,false);
        return new myViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {

        holder.feedNo.setText(noF[position]);
        holder.sender.setText(senderF[position]);
        holder.desFeed.setText(descripF[position]);
        holder.dateFeed.setText(dateF[position]);
    }

    @Override
    public int getItemCount() {
        return senderF.length;
    }

    public class myViewHolder extends RecyclerView.ViewHolder{

        TextView feedNo;
        TextView sender;
        TextView desFeed;
        TextView dateFeed;


        public myViewHolder(@NonNull View itemView) {
            super(itemView);

            feedNo = itemView.findViewById(R.id.ViewfeedNo);
            sender = itemView.findViewById(R.id.viewSenderF);
            desFeed = itemView.findViewById(R.id.viewfeedDescrip);
            dateFeed = itemView.findViewById(R.id.viewfeedDate);
        }
    }
}
