package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class sendfeedAll extends AppCompatActivity {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";
    private Spinner recipSpiner;
    private EditText feedDes;
    private Button sendFeedback;
    private String recipFeed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sendfeed_all);

        final String myID = getIntent().getStringExtra("theID");

        recipSpiner = findViewById(R.id.feedmakeSpiner);
        feedDes = findViewById(R.id.feedmakeView);
        sendFeedback = findViewById(R.id.editTextsendFeed);

        allEmployees(myID);

        sendFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RequestQueue queue = Volley.newRequestQueue(getBaseContext());
                String url = baseurl + "getallEmployeeAsync";

                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {

                                JSONArray jsonArray = null;
                                try {

                                    if(response.length()<20){
                                        Toast. makeText(getApplicationContext(), "Failure to retrieve employees", Toast. LENGTH_SHORT).show();
                                    }else{

                                        ArrayList<String> list = new ArrayList<>();
                                        jsonArray = new JSONArray(response);

                                        if (jsonArray != null) {
                                            int len = jsonArray.length();
                                            for (int i = 0; i < len; i++) {
                                                list.add(jsonArray.get(i).toString());
                                            }

                                            int recipientID = 0;
                                            for(String str : list){
                                                String[] sAll = str.split(":");

                                                if(recipFeed.contains(sAll[1]) && recipFeed.contains(sAll[2])){
                                                    recipientID = Integer.parseInt(sAll[6]);
                                                }

                                            }

                                            if(recipientID != 0){

                                                finallyComment(Integer.parseInt(myID), Integer.parseInt(myID), recipientID, feedDes.getText().toString(), "FEEDBACK", recipientID);

                                            }else{
                                                Toast. makeText(getApplicationContext(), "Failure to retrieve employee ids", Toast. LENGTH_SHORT).show();
                                            }

                                        }
                                    }

                                } catch (JSONException e) {
                                    Toast. makeText(getApplicationContext(), "Json error", Toast. LENGTH_SHORT).show();
                                }

                            }
                        },new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast. makeText(getApplicationContext(),"Volley Error",Toast. LENGTH_SHORT).show();
                    }
                });
                queue.add(stringRequest);
            }
        });
    }

    private void finallyComment(int cid, int sid, int rid, String d, String com, int ab) {

        RequestQueue queue = Volley.newRequestQueue(getBaseContext());

        String url = baseurl+"comment?C_ID=" + cid + "&&ID=" + sid + "&&Recipient=" + rid + "&&Descrip=" + d + "&&comment_Type=" + com + "&&compReceiver=" + ab;

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        int num = Integer.parseInt(response);

                        if (num == 1)
                        {
                            Toast.makeText(getApplicationContext(),"Feedback Received",Toast. LENGTH_SHORT).show();
                        }
                        else if (num == -1)
                        {
                            Toast.makeText(getApplicationContext(),"Something went wrong, please try again",Toast. LENGTH_SHORT).show();
                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),error.toString(),Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);


    }

    private void allEmployees(final String Eid) {
        RequestQueue queue = Volley.newRequestQueue(getBaseContext());
        String url = baseurl + "getallEmployeeAsync";


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        JSONArray jsonArray = null;
                        try {

                            if(response.length()<20){
                                Toast. makeText(getApplicationContext(), "Failure to retrieve employees", Toast. LENGTH_SHORT).show();
                            }else{

                                ArrayList<String> list = new ArrayList<>();
                                jsonArray = new JSONArray(response);

                                if (jsonArray != null) {
                                    int len = jsonArray.length();
                                    for (int i = 0; i < len; i++) {
                                        list.add(jsonArray.get(i).toString());
                                    }

                                    ArrayList<String> list2 = new ArrayList<>();
                                    for(String str : list){
                                        String[] sAll = str.split(":");

                                        if(!(sAll[6].equals(Eid))){
                                            list2.add(sAll[1]+" " +sAll[2]);
                                        }
                                    }

                                    ArrayAdapter<String> adapterrecip = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item,list2);
                                    adapterrecip.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                                    recipSpiner.setAdapter(adapterrecip);

                                    recipSpiner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                            recipSpiner.setOnItemSelectedListener(this);
                                            recipFeed = parent.getItemAtPosition(parent.getFirstVisiblePosition()).toString();

                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parent) {

                                        }
                                    });

                                }
                            }

                        } catch (JSONException e) {
                            Toast. makeText(getApplicationContext(), "Json error", Toast. LENGTH_SHORT).show();
                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"Volley Error",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);

    }
}