package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class viewMycommentsResearcher extends AppCompatActivity {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";
    private ArrayList<String> list = new ArrayList<String>();
    private RecyclerView recyclerV;
    private String recips[];
    private String aboutWho[];
    private String stats[];
    private String descrips[];
    private String typs[];
    private String dates[];
    private String nos[];
    private int num = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_mycomments_researcher);

        final String myID = getIntent().getStringExtra("theID");

        RequestQueue queue = Volley.newRequestQueue(getBaseContext());
        String url = baseurl + "viewComment_I_Made?id=" + myID;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.length() < 20){
                            Toast. makeText(getApplicationContext(), "You have made no comments", Toast. LENGTH_SHORT).show();
                        }else{
                            try {

                                JSONArray jsonArray = new JSONArray(response);
                                if (jsonArray != null) {
                                    int len = jsonArray.length();
                                    for (int i=0;i<len;i++){
                                        list.add(jsonArray.get(i).toString());
                                    }

                                    if(list!=null){

                                        recips = new String[list.size()];
                                        aboutWho = new String[list.size()];
                                        stats = new String[list.size()];
                                        descrips = new String[list.size()];
                                        typs = new String[list.size()];
                                        dates = new String[list.size()];
                                        nos = new String[list.size()];

                                        for(int i = 0; i < list.size();i++){
                                            String[] a = list.get(i).split(":");
                                            recips[i] = a[0];
                                            aboutWho[i] = a[1];
                                            stats[i] = a[2];
                                            descrips[i] = a[3];
                                            typs[i] = a[4];
                                            String[] sD = a[5].split(" ");
                                            dates[i] = sD[0];
                                            num++;
                                            nos[i] = String.valueOf(num);
                                        }

                                        if(recips!=null){

                                            recyclerviewAdapter adapterRecycle = new recyclerviewAdapter(getApplicationContext(),recips,aboutWho,stats,descrips,typs,dates,nos);

                                            recyclerV = (RecyclerView) findViewById(R.id.recycle);
                                            LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
                                            recyclerV.setLayoutManager(layoutManager);
                                            recyclerV.setAdapter(adapterRecycle);

                                        }else{
                                            Toast. makeText(getApplicationContext(),"null containers",Toast. LENGTH_SHORT).show();
                                        }

                                    }else{
                                        Toast. makeText(getApplicationContext(), "List was null", Toast. LENGTH_SHORT).show();
                                    }


                                }

                            } catch (JSONException e) {
                                Toast. makeText(getApplicationContext(), "Json error", Toast. LENGTH_SHORT).show();
                            }

                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"Failure to retrieve comments",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);


    }
}