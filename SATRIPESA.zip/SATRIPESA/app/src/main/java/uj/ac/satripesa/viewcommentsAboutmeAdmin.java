package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class viewcommentsAboutmeAdmin extends AppCompatActivity {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";
    private ArrayList<String> list = new ArrayList<String>();
    private RecyclerView recyclerAdmin;
    private String recips[];
    private String stats[];
    private String descrips[];
    private String typs[];
    private String dates[];
    private String nos[];
    private int num = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewcomments_aboutme_admin);

        final String myID = getIntent().getStringExtra("theID");

        RequestQueue queue = Volley.newRequestQueue(getBaseContext());
        String url = baseurl + "viewCommentAboutme?id=" + myID;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.length() < 20){
                            Toast. makeText(getApplicationContext(), "You have comments about yet", Toast. LENGTH_SHORT).show();
                        }else{
                            try {

                                JSONArray jsonArray = new JSONArray(response);
                                if (jsonArray != null) {
                                    int len = jsonArray.length();
                                    for (int i=0;i<len;i++){
                                        list.add(jsonArray.get(i).toString());
                                    }

                                    if(list!=null){

                                        recips = new String[list.size()];
                                        stats = new String[list.size()];
                                        descrips = new String[list.size()];
                                        typs = new String[list.size()];
                                        dates = new String[list.size()];
                                        nos = new String[list.size()];

                                        for(int i = 0; i < list.size();i++){
                                            String[] a = list.get(i).split(":");
                                            recips[i] = a[0];
                                            stats[i] = a[1];
                                            descrips[i] = a[2];
                                            typs[i] = a[3];
                                            String[] sD = a[4].split(" ");
                                            dates[i] = sD[0];
                                            num++;
                                            nos[i] = String.valueOf(num);
                                        }

                                        if(recips!=null){

                                            admincommentaboutAdapter adapterAdmin = new admincommentaboutAdapter(getApplicationContext(),recips,stats,descrips,typs,dates,nos);

                                            recyclerAdmin = (RecyclerView) findViewById(R.id.recycleAdmin);
                                            LinearLayoutManager layoutManagerAdmin = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
                                            recyclerAdmin.setLayoutManager(layoutManagerAdmin);
                                            recyclerAdmin.setAdapter(adapterAdmin);

                                        }else{
                                            Toast. makeText(getApplicationContext(),"null containers",Toast. LENGTH_SHORT).show();
                                        }

                                    }else{
                                        Toast. makeText(getApplicationContext(), "List was null", Toast. LENGTH_SHORT).show();
                                    }


                                }

                            } catch (JSONException e) {
                                Toast. makeText(getApplicationContext(), "Json error", Toast. LENGTH_SHORT).show();
                            }

                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"Failure to retrieve comments",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);

    }
}