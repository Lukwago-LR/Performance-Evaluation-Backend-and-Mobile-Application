package uj.ac.satripesa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class viewfeedAll extends AppCompatActivity {

    private String baseurl = "https://www.infotecker.co.za/api/SATRI_api/";
    private ArrayList<String> list = new ArrayList<String>();
    private RecyclerView recyclerF;
    private String senderF[];
    private String descripF[];
    private String dateF[];
    private String noF[];
    private int num = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewfeed_all);
        final String myID = getIntent().getStringExtra("theID");

        RequestQueue queue = Volley.newRequestQueue(getBaseContext());
        String url = baseurl + "getFeedback?id=" + myID;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,

                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if(response.length() < 20){
                            Toast. makeText(getApplicationContext(), "You have no feedback yet", Toast. LENGTH_SHORT).show();
                        }else{
                            try {

                                JSONArray jsonArray = new JSONArray(response);
                                if (jsonArray != null) {
                                    int len = jsonArray.length();
                                    for (int i=0;i<len;i++){
                                        list.add(jsonArray.get(i).toString());
                                    }

                                    if(list!=null){

                                        senderF = new String[list.size()];
                                        descripF = new String[list.size()];
                                        dateF = new String[list.size()];
                                        noF = new String[list.size()];

                                        for(int i = 0; i < list.size();i++){
                                            String[] a = list.get(i).split(":");
                                            senderF[i] = a[0];
                                            descripF[i] = a[1];
                                            String[] sD = a[3].split(" ");
                                            dateF[i] = sD[0];
                                            num++;
                                            noF[i] = String.valueOf(num);
                                        }

                                        if(senderF!=null){


                                            recycleviewFeed adapterrecycleFeed = new recycleviewFeed(getApplicationContext(),senderF,descripF,dateF,noF);

                                            recyclerF = (RecyclerView) findViewById(R.id.recyclefeed);
                                            LinearLayoutManager layoutManagerF = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
                                            recyclerF.setLayoutManager(layoutManagerF);
                                            recyclerF.setAdapter(adapterrecycleFeed);

                                        }else{
                                            Toast. makeText(getApplicationContext(),"null containers",Toast. LENGTH_SHORT).show();
                                        }

                                    }else{
                                        Toast. makeText(getApplicationContext(), "List was null", Toast. LENGTH_SHORT).show();
                                    }


                                }

                            } catch (JSONException e) {
                                Toast. makeText(getApplicationContext(), "Json error", Toast. LENGTH_SHORT).show();
                            }

                        }

                    }
                },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast. makeText(getApplicationContext(),"Failure to retrieve feedback",Toast. LENGTH_SHORT).show();
            }
        });
        queue.add(stringRequest);

    }
}