﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SATRI.Services;

namespace SATRI_REST_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SATRI_apiController : ControllerBase
    {
        protected readonly ISATRI_service Is;

        public SATRI_apiController(ISATRI_service _Is)
        {
            Is = _Is;
        }


        //EMPLOYEES

        [Route("getallEmployeeAsync")]
        [HttpGet]
        public string getallEmployeeAsync()
        {
            return JsonConvert.SerializeObject(Is.getallEmployeeAsync());
        }


        [Route("getEmployeeByUserType")]
        [HttpGet]
        public string getEmployeeByUserType(string userT)
        {
            return JsonConvert.SerializeObject(Is.getEmployeeByUserType(userT));
        }

        [Route("getEmpDetailsAsync")]
        [HttpGet]
        public string getEmpDetailsAsync(string email, string password)
        {
            return  JsonConvert.SerializeObject(Is.getEmpDetailsAsync(email, password));
        }

        [Route("getEmployeebyIdAsync")]
        [HttpGet]
        public string getEmployeebyIdAsync(int id)
        {
            return JsonConvert.SerializeObject(Is.getEmployeebyIdAsync(id));
        }

        [Route("Login")]
        [HttpGet]
        public string Login(string email, string password)
        {
            //return Is.Login(email, password);
            return JsonConvert.SerializeObject(Is.Login(email, password));
           
        }

        [Route("RegisterAsync")]
        [HttpPost, HttpGet]  
        public int RegisterAsync(string title, string firstname, string surname, string userType, string contact, string email, string password)
        {
            return Is.RegisterAsync(title, firstname, surname, userType, contact, email, password);
        }

        [Route("updateProfile")]
        [HttpGet, HttpPost]
        public int updateProfile(string contact, string email, string password, int ID)
        {
            return Is.updateProfile(contact, email, password, ID);
        }

        //FILES

        [Route("removeFile")]
        [HttpGet]
        public int removeFile(string fileID)
        {
            return Is.removeFile(fileID);
        }

        [Route("viewFiles")]
        [HttpGet]
        public string viewFiles(string id)
        {
            return  JsonConvert.SerializeObject(Is.viewFiles(id));
        }

        [Route("getForwardedFile")]
        [HttpGet]
        public string getForwardedFile(string receiver)
        {
            return JsonConvert.SerializeObject(Is.getForwardedFile(receiver));
        }

        [Route("uploadFile")]
        [HttpGet, HttpPost]
        public int uploadFile(int id, string fType, string fileName, int RecipID)
        {
            return Is.uploadFile(id, fType, fileName, RecipID);
        }

        //VERIFICATIONS

        [Route("UpdateVerifiedAccount")]
        [HttpGet]
        public int UpdateVerifiedAccount(int id, int veriferID)
        {
            return Is.UpdateVerifiedAccount(id, veriferID);
        }

        [Route("UpdateFiles")]
        [HttpGet]
        public int UpdateFiles(string fileid, int senderid, string receiverId, string filestatus)
        {
            return Is.UpdateFiles(fileid, senderid, receiverId, filestatus);
        }

        [Route("UpdateVerifiedComments")]
        [HttpGet]
        public int UpdateVerifiedComments(int C_ID, string status)
        {
            return Is.UpdateVerifiedComments(C_ID,status);
        }

        //COMMENTS

        [Route("comment")]
        [HttpGet]
        public int comment(int C_ID, int ID, int Recipient, string Descrip, string comment_Type, int compReceiver)
        {
            
            return Is.comment(C_ID, ID, Recipient, Descrip, comment_Type, compReceiver);
        }

        [Route("updatecommentadmin")]
        [HttpGet]
        public int updatecommentadmin(string C_ID)
        {
            return Is.updatecommentadmin(C_ID);
        }

        [Route("viewCommentAboutme")]
        [HttpGet]
        public string viewCommentAboutme(string id)
        {
            return  JsonConvert.SerializeObject(Is.viewCommentAboutme(id));
        }

        [Route("viewComment_I_Made")]
        [HttpGet]
        public string viewComment_I_Made(string id)
        {
            return JsonConvert.SerializeObject(Is.viewComment_I_Made(id));
        }

        [Route("viewCommentaboutAdministrator")]
        [HttpGet]
        public string viewCommentaboutAdministrator(int id)
        {
            return JsonConvert.SerializeObject(Is.viewCommentaboutAdministrator(id));
        }

        [Route("getFeedback")]
        [HttpGet]
        public string getFeedback(string id)
        {
            return JsonConvert.SerializeObject(Is.getFeedback(id));
        }


        [Route("getcommentNo")]
        [HttpGet]
        public int getcommentNo(string id)
        {
            return Is.getcommentNo(id);
        }

        [Route("getfeedbackNo")]
        [HttpGet]
        public int getfeedbackNo(string id)
        {
            return Is.getfeedbackNo(id);
        }


        //EVALUATIONS

        [Route("gettotalperformanceGrade")]
        [HttpGet]
        public decimal gettotalperformanceGrade()
        {
            return Is.gettotalperformanceGrade(); 
        }

        [Route("getresearcherGrade")]
        [HttpGet]
        public string getresearcherGrade(int id)
        {
            return JsonConvert.SerializeObject(Is.getresearcherGrade(id));
        }

        [Route("getadminGrade")]
        [HttpGet]
        public decimal getadminGrade(int id)
        {
            return Is.getadminGrade(id);
        }


        [Route("evaluation_totalperf_percent_updating_Grades")]
        [HttpGet]
        public string evaluation_totalperf_percent_updating_Grades()
        {
            return JsonConvert.SerializeObject(Is.evaluation_totalperf_percent_updating_Grades());
        }

        [Route("getaccountbyUserType")]
        [HttpGet]
        public string getaccountbyUserType(string userT)
        {
            return JsonConvert.SerializeObject(Is.getaccountbyUserType(userT));
        }
    }
}
