﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfServiceSATRI
{

    public class CommentClass
    {
       private DataClasses1DataContext db = new DataClasses1DataContext();
       private int IDET;

        public CommentClass()
        {
        }

        public int comment(int C_ID, int Sender_ID, int Recipient_ID, string Descrip, string comment_Type, int compReceiver)
        {
            IDET = random() +  C_ID;
            Comment C = new Comment
            {
                C_ID = Convert.ToString(IDET),
                E_Staff_ID = Sender_ID,
                C_Recipient = Convert.ToString(Recipient_ID),
                C_Date = DateTime.Today,
                C_Status = "N",
                C_Description = Descrip
            };
            db.Comments.InsertOnSubmit(C);
          

            if (comment_Type.Equals("FEEDBACK"))
            {
                Feedback F = new Feedback
                {
                    C_ID = Convert.ToString(IDET),
                    Feedback_Type = "NOTE"
                };
                db.Feedbacks.InsertOnSubmit(F);


            }else if (comment_Type.Equals("COMPLEMENT"))
            {
                Complement Comp = new Complement 
                {
                    C_ID = Convert.ToString(IDET),
                    Complement_To = Convert.ToString(compReceiver)
                };
                db.Complements.InsertOnSubmit(Comp);

            }
            else if (comment_Type.Equals("COMPLAINT"))
            {
               Complaint X = new Complaint
                {
                    C_ID = Convert.ToString(IDET),
                    Complaint_About = Convert.ToString(compReceiver)
                };
                db.Complaints.InsertOnSubmit(X);

            }

            try
            {
                db.SubmitChanges();
                return 1;
            }
            catch (Exception ex)
            {
                ex.GetBaseException();
                return -1;
            }

        }

        public List<string> myComments(string id)
        {
            List<string> list1 = new List<string>();
            List<string> list2 = new List<string>();
            List<string> list3 = new List<string>();



            dynamic l = (from u in db.Complements select u.C_ID).ToList();
            if (l != null)
            {
                foreach (string c in l)
                {
                    list1.Add(c);
                }

            }

            if (list1.Count != 0)
            {

                foreach (string i in list1)
                {
                    var l3 = (from u in db.Comments where u.C_ID.Equals(i) && u.E_Staff_ID.Equals(id) select u).FirstOrDefault();

                    if (l3 != null)
                    {
                        if (l3.C_Status.Equals("N"))
                        {
                            l3.C_Status = "Y";
                            try
                            {

                                db.SubmitChanges();

                            }
                            catch (Exception e)
                            {
                                e.GetBaseException();
                            }

                        }

                        var emp = (from u in db.Accounts where u.E_Staff_ID.Equals(l3.C_Recipient) select u).FirstOrDefault();
                        string str = emp.E_Surname_Name + " " + emp.E_First_Name + ":" + l3.C_Status + ":" + l3.C_Description + ":" + "COMPLEMENT" + ":" + l3.C_Date;
                        list3.Add(str);

                    }
                    

                }
            }


            dynamic l2 = (from u in db.Complaints select u.C_ID).ToList();
            if (l2 != null)
            {
                foreach (string c2 in l2)
                {
                    list2.Add(c2);
                }

            }
            if (list2.Count != 0)
            {

                foreach (string i in list2)
                {
                    var l3 = (from u in db.Comments where u.C_ID.Equals(i)  && u.E_Staff_ID.Equals(id) select u).FirstOrDefault();

                    if (l3 != null)
                    {
                        if (l3.C_Status.Equals("N"))
                        {
                            l3.C_Status = "Y";
                            try
                            {

                                db.SubmitChanges();

                            }
                            catch (Exception e)
                            {
                                e.GetBaseException();


                            }

                        }

                        var emp = (from u in db.Accounts where u.E_Staff_ID.Equals(l3.C_Recipient) select u).FirstOrDefault();
                        string str = emp.E_Surname_Name + " " + emp.E_First_Name + ":" + l3.C_Status + ":" + l3.C_Description + ":" + "COMPLAINT" +":"+ l3.C_Date;
                        list3.Add(str);

                    }                  
                   
                }

            }

            if (list3.Count == 0)
            {
                return null;
            }
            else
            {
                return list3;

            }


        }

        public List<string> CommentsAboutme(string id)
        {
            List<string> list1 = new List<string>();
            List<string> list2 = new List<string>();
            List<string> list3 = new List<string>();



            dynamic l = (from u in db.Complements where u.Complement_To.Equals(id) select u.C_ID).ToList();
            if (l != null)
            {
                foreach (string c in l)
                {
                   list1.Add(c);
                }
                
            }

            if (list1.Count != 0)
            {

                foreach (string i in list1)
                {
                    var l3 = (from u in db.Comments where u.C_ID.Equals(i) select u).FirstOrDefault();

                    if(l3 != null)
                    {
                        if (l3.C_Status.Equals("N"))
                        {
                            l3.C_Status = "Y";
                            try
                            {

                                db.SubmitChanges();

                            }
                            catch (Exception e)
                            {
                                e.GetBaseException();
                            }
                        }

                        var emp = (from u in db.Accounts where u.E_Staff_ID.Equals(l3.C_Recipient) select u).FirstOrDefault();
                        string str = emp.E_Surname_Name + " " + emp.E_First_Name + ":" + l3.C_Description + ":" + "COMPLEMENT" + ":"+ l3.C_Date;
                        list3.Add(str);

                    }

                  

                }
            }


            dynamic l2 = (from u in db.Complaints where u.Complaint_About.Equals(id) select u.C_ID).ToList();
            if (l2 != null)
            {              
                foreach (string c2 in l2)
                {
                    list2.Add(c2);
                }

            }
            if (list2.Count != 0)
            {


                foreach (string i in list2)
                {
                    var l3 = (from u in db.Comments where u.C_ID.Equals(i) select u).FirstOrDefault();

                    if(l3 != null)
                    {
                        if (l3.C_Status.Equals("N"))
                        {
                            l3.C_Status = "Y";
                            try
                            {

                                db.SubmitChanges();

                            }
                            catch (Exception e)
                            {
                                e.GetBaseException();


                            }

                        }

                        var emp = (from u in db.Accounts where u.E_Staff_ID.Equals(l3.C_Recipient) select u).FirstOrDefault();
                        string str = emp.E_Surname_Name + " " + emp.E_First_Name + ":" + l3.C_Description + ":" + "COMPLAINT" + ":" + l3.C_Date;
                        list3.Add(str);


                    }


                }

            }

            if (list3.Count == 0)
            {
                return null;
            }
            else
            {
                return list3;

            }



        }

        public List<string> getmyFeedback(string id)
        {
            List<string> list1 = new List<string>();

            dynamic c2 = (from u in db.Feedbacks select u.C_ID).ToList();
            if (c2 != null)
            {
                foreach (string sr2 in c2)
                {
                    var l = (from u in db.Comments where u.C_ID.Equals(sr2) && u.C_Recipient.Equals(id) select u).FirstOrDefault();
                    if (l!= null)
                    {
                        if (l.C_Status.Equals("N"))
                        {
                            l.C_Status = "Y";
                            try
                            {

                                db.SubmitChanges();

                            }
                            catch (Exception e)
                            {
                                e.GetBaseException();
                            }
                        }
                        var emp = (from u in db.Accounts where u.E_Staff_ID.Equals(l.E_Staff_ID) select u).FirstOrDefault();
                        string str = emp.E_Surname_Name + " " + emp.E_First_Name + ":" + l.C_Description + ":" + "FEEDBACK" + ":" + l.C_Date;
                        list1.Add(str);
                    }

                }

            }

            if(list1.Count != 0)
            {
                return list1;
            }
            else
            {
                return null;
            }

        }

        public List<string> viewcommentAdmin(string id)
        {
            List<string> list1 = new List<string>();
 
             
            dynamic l = (from u in db.Accounts where u.E_UserType.Equals("ADMINISTRATOR") select u).ToList();
            foreach(Account s in l)
            {
                dynamic c = (from u in db.Complements where u.Complement_To.Equals(s.E_Staff_ID) select u.C_ID).ToList();
                if (c != null)
                {
                    foreach ( string str in c)
                    {
                        var lc = (from u in db.Comments where u.C_ID.Equals(str) && u.C_Recipient.Equals(id) && !(u.C_Status.Equals("VERIFIED")) select u).FirstOrDefault();
                        if (lc != null)
                        {
                            string first = s.E_Surname_Name + " " + s.E_First_Name + ":" + s.E_UserType + ":" + lc.C_Description + ":" + "COMPLEMENT" + ":" + lc.C_ID + ":" + s.E_Staff_ID + ":" + lc.E_Staff_ID + ":" + lc.C_Date;
                            list1.Add(first);
                        }
                        
                    }

                }
                dynamic x = (from u in db.Complaints where u.Complaint_About.Equals(s.E_Staff_ID) select u.C_ID).ToList();
                if (x != null)
                {
                    foreach (string str1 in x)
                    {
                        var lc1 = (from u in db.Comments where u.C_ID.Equals(str1) && u.C_Recipient.Equals(id) && !(u.C_Status.Equals("VERIFIED")) select u).FirstOrDefault();

                        if (lc1 != null)
                        {
                            string first1 = s.E_Surname_Name + " " + s.E_First_Name + ":" + s.E_UserType + ":" + lc1.C_Description + ":" + "COMPLAINT" + ":"+ lc1.C_ID + ":" + s.E_Staff_ID + ":" + lc1.E_Staff_ID + ":" + lc1.C_Date;
                            list1.Add(first1);
                        }
                       
                    }

                }
            }
            if (list1.Count == 0)
            {
                return null;
            }
            else
            {
                return list1;
            }

        }

        public List<int> getcommentNumber(string id)
        {
            List<string> list1 = new List<string>();
            List<int> list = new List<int>();
            int num1 = 0;
            int num2 = 0;

            dynamic c = (from u in db.Complements where u.Complement_To.Equals(id) select u.C_ID).ToList();
            if (c != null)
            {
                foreach (string s in c)
                {
                    var l = (from u in db.Comments where u.C_ID.Equals(s) && u.C_Status.Equals("N") select u.C_ID).FirstOrDefault();
                    if (l != null)
                    {
                        list1.Add(l);
                        num1++;
                    }

                }               
                
            }

            dynamic c1 = (from u in db.Complaints where u.Complaint_About.Equals(id) select u.C_ID).ToList();
            if (c1 != null)
            {
                foreach (string sr in c1)
                {
                    var lc = (from u in db.Comments where u.C_ID.Equals(sr) && u.C_Status.Equals("N") select u.C_ID).FirstOrDefault();
                    if (lc != null)
                    {
                        list1.Add(lc);
                        num1++;
                    }

                }

            }

            dynamic c2 = (from u in db.Feedbacks select u.C_ID).ToList();
            if (c2 != null)
            {
                foreach (string sr2 in c2)
                {
                    var lc2 = (from u in db.Comments where u.C_ID.Equals(sr2) && u.C_Status.Equals("N") && u.C_Recipient.Equals(id) select u.C_ID).FirstOrDefault();
                    if (lc2 != null)
                    {
                        list1.Add(lc2);
                        num2++;
                    }

                }

            }

            dynamic r = (from u in db.Comments where u.C_Recipient.Equals(id) && u.C_Status.Equals("N") select u.C_ID).ToList();
            foreach (string str in r)
            {
                if (!(list1.Contains(str)))
                {
                    num1++;
                }

            }

            list.Add(num1);
            list.Add(num2);

            return list;
           
        }


        private int random()
        {
            Random num = new Random();
            return num.Next(2000000, 5000000);
        }
    }
}