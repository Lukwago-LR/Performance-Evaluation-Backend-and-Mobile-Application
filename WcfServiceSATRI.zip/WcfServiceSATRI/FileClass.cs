﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfServiceSATRI
{
    public class manageFile
    {
        private DataClasses1DataContext db = new DataClasses1DataContext();
        private int U_ID;
        private string F_ID;
        private int Recip;

        public manageFile()
        {

        }

        public int addFile(int userID, string fileType, string fileName, string Recipient)
        {
            U_ID = userID;
            F_ID = Convert.ToString(new  Random().Next(9000,100000) + userID);
           

            if (Recipient.Equals("EXECUTIVE_DIRECTOR"))
            {
                var ED = (from u in db.Accounts where u.E_UserType.Equals("EXECUTIVE_DIRECTOR") select u).FirstOrDefault();
                Recip = ED.E_Staff_ID;
            }
            else if(Recipient.Equals("SENIOR_RESEARCHER"))
            {
                var SR = (from u in db.Accounts where u.E_UserType.Equals("SENIOR_RESEARCHER") select u).FirstOrDefault();
                Recip = SR.E_Staff_ID;
            }

            File f = new File
            {
                F_ID = F_ID,
                F_Name = fileName,
                F_Date = DateTime.Today,
                F_Type = fileType,               
                F_Status = "FORWARDED",
                F_Recipient = Convert.ToString(Recip)
            };
            db.Files.InsertOnSubmit(f);

            File_Employee_Bridge feb = new File_Employee_Bridge
            {
                F_ID = F_ID,
                E_Staff_ID = U_ID
            };
            db.File_Employee_Bridges.InsertOnSubmit(feb);
           

            try
            {
                int i = new CommentClass().comment(U_ID, U_ID, Recip, "Request to verify file", "FEEDBACK", 0);
                db.SubmitChanges();
                return 1;
            }
            catch (Exception ex)
            {
                ex.GetBaseException();
                return -1;
            }

        }

        public int removeFile(int fileID)
        {
            var f = (from u in db.Files where u.F_ID.Equals(fileID) select u).FirstOrDefault();
            if (f != null)
            {
                f.F_Status = "DELETED";
                db.SubmitChanges();
                return 1;
            }
            else
            {
                return -1;
            }

        }
        public List<string> viewFile(int ID)
        {
            List<string> l = new List<string>();
            dynamic List1 = (from u in db.File_Employee_Bridges where u.E_Staff_ID.Equals(ID) select u.F_ID).ToList();


            foreach (string s in List1)
            {
                
                var file = (from u in db.Files where !(u.F_Status.Equals("DELETED")) && u.F_ID.Equals(s) select u).FirstOrDefault();

                if (file != null)
                {
                    string sam = file.F_Name + ":" + file.F_Type + ":" + file.F_Status + ":" + file.F_ID;
                    l.Add(sam);
                }
              
            }

            if(l.Count == 0)
            {
                return null;
            }
            else
            {
                return l;

            }           

        }
     
    }
}