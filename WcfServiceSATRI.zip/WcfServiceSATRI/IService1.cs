﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfServiceSATRI
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.

    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        int Register(string title, string firstname, string surname, string userType, string contact, string email, string password);

        [OperationContract]
        List<string> getEmployee(string ID);

        [OperationContract]
        List<string> getAllEmployee();

        [OperationContract]
        Account getEmpDetails(string email, string password);

        [OperationContract]
        string[] Login(string email, string password);

        [OperationContract]
        int updateProfile();

        [OperationContract]
        int removeFile(int fileID);//unforward the file

        [OperationContract]
        List<string> getForwardedFile(string receiver);

        [OperationContract]
        int comment(int C_ID, int ID, int Recipient, string Descrip, string comment_Type, int compReceiver);

        [OperationContract]
        List<string> getAccounts(string userType);

        [OperationContract]
        List<string> viewFiles(string id);


        [OperationContract]
        List<string> viewCommentAboutme(string id);

        [OperationContract]
        List<string> viewmyComment(string id);

        [OperationContract]
        List<string> viewCommentaboutAdministrator(string id);

        [OperationContract]
        int  UpdateVerifiedAccount(int id, string userT);

        [OperationContract]
        int UpdateVerifiedFiles(int fileid, int senderid, string userT, string receiverId);

        [OperationContract]
        int uploadFile(string id, string text, string fileName, string Recip);

        [OperationContract]
        int UpdateVerifiedComments(int C_ID, string adminId, string userT, string receiverId);

        [OperationContract]
        List<int> getcommentNo(string id);

        [OperationContract]
        List<string> getFeedback(string id);

    }
}
;