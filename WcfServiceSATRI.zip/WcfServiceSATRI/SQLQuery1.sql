﻿SELECT *
FROM Employee INNER JOIN Account ON Employee.E_Staff_ID = Account.E_Staff_ID;
