﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace WcfServiceSATRI
{
    public class Security
    {
        
        public Security()
        {

        }

        public string Mtdpassword(string password)
        {
            SHA1 algorithmn = SHA1.Create();   
;           byte[]  array = algorithmn.ComputeHash(Encoding.Default.GetBytes(password));
            string hashedPassword = "";
            for (int i = 0; i < array.Length - 1; i++)
            {
                hashedPassword += array[i].ToString("x2");
            }

            return hashedPassword;
        }
    }

   
}