﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WcfServiceSATRI
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        private DataClasses1DataContext db = new DataClasses1DataContext();

       public List<string> getEmployee(string ID)
        {
            var emp  = (from u in db.Accounts where u.E_Staff_ID.Equals(ID) select u).FirstOrDefault();
   
            if (emp == null)
            {
                return null;

            }
            else
            {
                List<string> l = new List<string>();
                l.Add(emp.E_UserType);
                l.Add(emp.E_Surname_Name);
                l.Add(emp.E_First_Name);
                l.Add(emp.E_Password);
                l.Add(emp.E_Contact);
                l.Add(emp.E_Email);
                l.Add(Convert.ToString(emp.E_Staff_ID));
                return l;
            }
        }

        public List<string> getAllEmployee()
        {
            dynamic l = (from u in db.Accounts select u).ToList();
            if(l != null)
            {
                List<string> lis = new List<string>();
                foreach (Account emp in l)
                {

                    string str = emp.E_UserType + ":" + emp.E_Surname_Name + ":" + emp.E_First_Name + ":" + emp.E_Password + ":" + emp.E_Contact + ":" + emp.E_Email + ":" + Convert.ToString(emp.E_Staff_ID);
                    lis.Add(str);
                }
                return lis;
            }
            else{
                return null;
            }

        }

        public Account getEmpDetails(string email, string password)
        {
            Security c = new Security();
            string w = c.Mtdpassword(password);
            var account = (from u in db.Accounts where u.E_Email.Equals(email) && u.E_Password.Equals(w) select u).FirstOrDefault();

            if (account == null)
            {
              
                return null;

            }
            else
            {
       
                return account;
            }

        }

        public int Register(string title, string firstname, string surname, string userType, string contact ,string email, string password)
        {
            var user = getEmpDetails(email, password);
            if(user == null)
            {
                Security c = new Security();
                string s =  c.Mtdpassword(password);
                Account A = new Account()
                {
                    E_First_Name = firstname,
                    Title = title,
                    E_Surname_Name = surname,
                    E_UserType = userType,
                    E_Contact = contact,
                    E_Email = email,
                    Account_Status = "UNVERIFIED",
                    E_Password = s
                };
                db.Accounts.InsertOnSubmit(A);


                try
                {
                    db.SubmitChanges();
                    //Send Notification to the Person who verifies

                    if (userType.Equals("ADMINISTRATOR"))
                    {
                        var ED = (from u in db.Accounts where u.E_UserType.Equals("EXECUTIVE_DIRECTOR") select u).FirstOrDefault();

                        return comment(ED.E_Staff_ID, ED.E_Staff_ID, ED.E_Staff_ID, "Request to verify account", "FEEDBACK", 0);
                    }
                    else if (userType.Equals("RESEARCHER"))
                    {
                        var SR = (from u in db.Accounts where u.E_UserType.Equals("SENIOR_RESEARCHER") select u).FirstOrDefault();
                        return comment(SR.E_Staff_ID, SR.E_Staff_ID, SR.E_Staff_ID, "Request to verify account", "FEEDBACK", 0);

                    }
                    return 1;
                }
                catch (Exception e)
                {
                    e.GetBaseException();
                    return -1;
                }

            }
            else
            {
                return 0;//user exists already
            }
        }

        public string[] Login(string email, string password)
        {
            var acc = getEmpDetails(email,password);
            string[] details = new string[3];
            if (acc != null)
            {
                details[0] = acc.E_Staff_ID.ToString();
                details[1] = acc.E_UserType;
                details[2] = acc.Account_Status;
                return details;

            }else
            {
                return null;
            }
       
        }


        public int updateProfile()
        {
            throw new NotImplementedException();
        }

        public int uploadFile(string id, string text, string fileName, string Recip)
        {
            manageFile mF = new manageFile();
            int n = Convert.ToInt32(id);
            return mF.addFile(n,text,fileName,Recip);
            
        }

        public int removeFile(int fileID)
        {
            manageFile mF = new manageFile();
            return mF.removeFile(fileID);
        }

        public List<string> getForwardedFile(string receiver)
        {
            Verification V = new Verification();
            return V.getforwadedFiles(receiver);
        }

        public int comment(int C_ID, int ID, int Recipient, string Descrip, string comment_Type, int comp)
        {
            return new CommentClass().comment(C_ID,ID,Recipient,Descrip,comment_Type,comp);
        }

    

        public List<string> getAccounts(string userType)
        {
            Verification V = new Verification();
            return V.getAccount(userType);
        }

       public int  UpdateVerifiedAccount(int id, string userT)
        {
            Verification V = new Verification();
            return V.updateAccount(id, userT);          
            
        }

        public List<string> viewmyComment(string id)
        {
            return new CommentClass().myComments(id);
        }

        public List<string> viewCommentAboutme(string id)
        {
            return new CommentClass().CommentsAboutme(id);
        }


        public List<string> viewCommentaboutAdministrator(string id)
        {
            return new CommentClass().viewcommentAdmin(id);
        }

        public int UpdateVerifiedFiles(int fileid, int senderid, string userT, string receiverId)
        {
           return  new Verification().updateFile(fileid, senderid, userT, receiverId);
        }

        public List<string> viewFiles(string id)
        {
            return new manageFile().viewFile(Convert.ToInt32(id));
        }

        public int UpdateVerifiedComments(int C_ID, string adminId, string userT, string receiverId)
        {
            return new Verification().UpdateVerifiedComments(C_ID, adminId, userT, receiverId);
        }

        public List<int> getcommentNo(string id)
        {
            return new CommentClass().getcommentNumber(id);
        }

       public List<string> getFeedback(string id)
        {
            return new CommentClass().getmyFeedback(id);
        }

    }
}
