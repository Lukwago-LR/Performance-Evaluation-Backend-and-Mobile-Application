﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfServiceSATRI
{
    public class Verification 
    {
        private DataClasses1DataContext db = new DataClasses1DataContext();

        public Verification()
        {
          
        }

        public List<string> getAccount(string userType)
        {
            List<string> l = new List<string>();     
            dynamic accountList = (from u in db.Accounts where u.Account_Status.Equals("N") && u.E_UserType.Equals(userType) select u).ToList();
            foreach(Account c in accountList){

                l.Add(Convert.ToString(c.E_Staff_ID));
            }
            return l;

        }

        public int updateAccount(int id, string userT)
        {
            var account = (from u in db.Accounts where u.E_Staff_ID.Equals(id) select u).FirstOrDefault();
            var com = (from u in db.Comments where u.E_Staff_ID.Equals(id) select u).FirstOrDefault();

            if (account != null && com != null)
            {
                account.Account_Status = "VERIFIED";
                com.C_Status = "Y";

                if (userT.Equals("EXECUTIVE_DIRECTOR"))
                {
                    var ED = (from u in db.Accounts where u.E_UserType.Equals("EXECUTIVE_DIRECTOR") select u).FirstOrDefault();
                    int num = new CommentClass().comment(ED.E_Staff_ID, ED.E_Staff_ID, id, "Account Verified", "FEEDBACK", 0);
                }
                else
                {
                    var SR = (from u in db.Accounts where u.E_UserType.Equals("SENIOR_RESEARCHER") select u).FirstOrDefault();
                    int num = new CommentClass().comment(SR.E_Staff_ID, SR.E_Staff_ID, id, "Account Verified", "FEEDBACK", 0);

                }                

                try
                {
                  
                    db.SubmitChanges();
                    return 1;
                }
                catch (Exception e)
                {
                    e.GetBaseException();
                    return -1;
                }

            }
            else{
                return 0;
            }
           
        }


        public List<string> getforwadedFiles(string receiverID)
        {
            List<string> l = new List<string>();
            dynamic List1 = (from u in db.Files where u.F_Status.Equals("FORWARDED") && u.F_Recipient.Equals(receiverID) select u).ToList();
          
          
            foreach (File s in List1)
            {
                int id =  (from u in db.File_Employee_Bridges where u.F_ID.Equals(s.F_ID) select u.E_Staff_ID).FirstOrDefault();

                string sam = s.F_Name + ":" + s.F_Type + ":" + Convert.ToString(id) + ":" + s.F_ID;

                l.Add(sam);
            }
            return l;

        }

        public int updateFile(int fileid, int senderid, string userT, string receiverId)
        {
            var file = (from u in db.Files where u.F_ID.Equals(fileid) select u).FirstOrDefault();
            var com = (from u in db.Comments where u.E_Staff_ID.Equals(senderid)&& u.C_Recipient.Equals(receiverId) && u.C_Description.Equals("Request to verify file") select u).FirstOrDefault();

            if (file != null && com != null)
            {
                file.F_Status= "VERIFIED";
                com.C_Status = "Y";

                if (userT.Equals("EXECUTIVE_DIRECTOR"))
                {
                   
                    int num = new CommentClass().comment(Convert.ToInt32(receiverId), Convert.ToInt32(receiverId), senderid, "File Verified", "FEEDBACK", 0);
                }
                else
                {
                   
                    int num = new CommentClass().comment(Convert.ToInt32(receiverId), Convert.ToInt32(receiverId), senderid, "File Verified", "FEEDBACK", 0);

                }

                try
                {

                    db.SubmitChanges();
                    return 1;
                }
                catch (Exception e)
                {
                    e.GetBaseException();
                    return -1;
                }
            }
            else
            {
                return 0;
            }

        }

        public int UpdateVerifiedComments(int Cid, string adminId, string userT, string receiverId)
        {
            var comm = (from u in db.Comments where u.C_ID.Equals(Cid) select u).FirstOrDefault();

            if (comm != null)
            {
                comm.C_Status = "VERIFIED";

                if (userT.Equals("EXECUTIVE_DIRECTOR"))
                {

                    int num = new CommentClass().comment(Convert.ToInt32(receiverId), Convert.ToInt32(receiverId), Convert.ToInt32(adminId), "Comment Verified", "FEEDBACK", 0);
                }
                else
                {
                    var SR = (from u in db.Accounts where u.E_UserType.Equals("SENIOR_RESEARCHER") select u).FirstOrDefault();
                    int num = new CommentClass().comment(Convert.ToInt32(receiverId), Convert.ToInt32(receiverId), Convert.ToInt32(adminId), "Comment Verified", "FEEDBACK", 0);

                }
                try
                {

                    db.SubmitChanges();
                    return 1;
                }
                catch (Exception e)
                {
                    e.GetBaseException();
                    return -1;
                }

            }
            else
            {
                return 0;
            }
        }

    }

}